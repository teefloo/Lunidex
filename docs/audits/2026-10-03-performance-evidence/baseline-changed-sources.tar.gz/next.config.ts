import type { NextConfig } from "next";
import { dirname } from "path";
import { fileURLToPath } from "url";
import withPWAInit from "@ducanh2912/next-pwa";
import { withSentryConfig } from "@sentry/nextjs/config";

const projectRoot = dirname(fileURLToPath(import.meta.url));

const withPWA = withPWAInit({
  dest: "public",
  // The generated entry registers without handling rejected promises. Keep
  // registration under the app's control so transient 429/5xx responses do
  // not become unhandled browser errors.
  register: false,
  disable: process.env.NODE_ENV === "development",
  fallbacks: {
    document: "/offline",
  },
  workboxOptions: {
    skipWaiting: true,
    importScripts: ["/push-worker.js"],
    runtimeCaching: [
      {
        urlPattern: /^https:\/\/pokeapi\.co\/api\/.*$/i,
        handler: "NetworkFirst",
        options: {
          cacheName: "pokeapi-data",
          expiration: {
            maxEntries: 200,
            maxAgeSeconds: 86400,
          },
          networkTimeoutSeconds: 10,
        },
      },
      {
        urlPattern: /^https:\/\/api\.tcgdex\.net\/.*$/i,
        handler: "NetworkFirst",
        options: {
          cacheName: "tcgdex-data",
          expiration: {
            maxEntries: 100,
            maxAgeSeconds: 86400,
          },
          networkTimeoutSeconds: 10,
        },
      },
      {
        urlPattern: ({ sameOrigin, url }: { sameOrigin: boolean; url: URL }) =>
          sameOrigin && url.pathname === "/api/tcg/sets",
        handler: "NetworkFirst",
        options: {
          // The catalog is public and safe to reuse when an installed PWA is
          // offline or the server function is temporarily unavailable.
          cacheName: "tcg-collection-catalog-v1",
          expiration: {
            maxEntries: 8,
            maxAgeSeconds: 86400,
          },
          networkTimeoutSeconds: 5,
          cacheableResponse: { statuses: [200] },
        },
      },
      {
        urlPattern: ({ sameOrigin, url }: { sameOrigin: boolean; url: URL }) =>
          sameOrigin && url.pathname === "/api/tcg/collection/set-cards",
        handler: "NetworkFirst",
        options: {
          // Set card projections are public and can be reused by the PWA while
          // the server function or upstream price service is temporarily slow.
          cacheName: "tcg-collection-set-cards-v1",
          expiration: {
            maxEntries: 32,
            maxAgeSeconds: 86400,
          },
          networkTimeoutSeconds: 5,
          cacheableResponse: { statuses: [200] },
        },
      },
      {
        urlPattern: /^https:\/\/raw\.githubusercontent\.com\/PokeAPI\/.*$/i,
        handler: "CacheFirst",
        options: {
          cacheName: "pokeapi-sprites",
          expiration: {
            maxEntries: 300,
            maxAgeSeconds: 604800,
          },
          cacheableResponse: { statuses: [200] },
        },
      },
      {
        urlPattern: ({ sameOrigin, url }: { sameOrigin: boolean; url: URL }) =>
          sameOrigin && /\.(?:png|jpg|jpeg|gif|webp|avif|svg|ico)$/i.test(url.pathname),
        handler: "CacheFirst",
        options: {
          cacheName: "static-images-v2",
          expiration: {
            maxEntries: 200,
            maxAgeSeconds: 604800,
          },
          cacheableResponse: { statuses: [200] },
        },
      },
      {
        urlPattern: /\/_next\/static.+\.js$/i,
        handler: "CacheFirst",
        options: {
          // Bump the cache namespace when the app shell changes so a service
          // worker upgraded after a deployment cannot reuse chunks from an
          // older HTML document.
          cacheName: "next-static-js-v2",
          expiration: {
            maxEntries: 100,
            maxAgeSeconds: 31536000,
          },
        },
      },
      {
        urlPattern: /\/_next\/static.+\.css$/i,
        handler: "CacheFirst",
        options: {
          cacheName: "next-static-css-v2",
          expiration: {
            maxEntries: 50,
            maxAgeSeconds: 31536000,
          },
        },
      },
      {
        urlPattern: ({ url }: { url: URL }) => {
          const isSameOrigin = self.location.origin === url.origin;
          if (!isSameOrigin) return false;
          const pathname = url.pathname.replace(/^\/(?:en|fr|es|de|it|ja|ko|zh)(?=\/|$)/i, '') || '/';
          // Localized URLs are rewritten internally, so normalize before
          // excluding APIs and auth pages from the document cache.
          if (/^\/(?:api|auth)(?:\/|$)/i.test(pathname)) return false;
          if (pathname.startsWith("/offline")) return false;
          return pathname.startsWith("/");
        },
        handler: "NetworkFirst",
        options: {
          // Bump the namespace when the page eligibility rules change so
          // entries created by an older worker cannot be reused.
          cacheName: "pages-v3",
          expiration: {
            maxEntries: 50,
            maxAgeSeconds: 86400,
          },
          networkTimeoutSeconds: 10,
        },
      },
    ],
  },
});

// Dev-only connect-src additions (localhost dev server / Agentation).
// Excluded from production to avoid leaking infra details and to enforce
// strict-origin connections.
const devConnectSrc =
  process.env.NODE_ENV === 'development'
    ? ' http://localhost:4747 http://127.0.0.1:4747'
    : '';

// unsafe-eval is required by Webpack HMR in dev; strip it in production.
const scriptSrc =
  process.env.NODE_ENV === 'development'
    ? "'self' 'unsafe-inline' 'unsafe-eval' blob: https://va.vercel-scripts.com https://*.posthog.com"
    : "'self' 'unsafe-inline' https://va.vercel-scripts.com https://*.posthog.com";

const csp = [
  "default-src 'self'",
  `script-src ${scriptSrc}`,
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' https://raw.githubusercontent.com https://pokeapi.co https://images.scrydex.com https://www.cardtrader.com https://images.pokemontcg.io https://assets.tcgdex.net https://images.tcgdex.net https://tcg.pokemon.com https://mcdn.pokemon.com https://dz3we2x72f7ol.cloudfront.net https://*.googleusercontent.com https://avatars.githubusercontent.com data: blob: https://api.tcgdex.net",
  "font-src 'self' data:",
  "media-src 'self' https://raw.githubusercontent.com",
  `connect-src 'self'${devConnectSrc} https://va.vercel-scripts.com https://vitals.vercel-insights.com https://*.ingest.sentry.io https://*.ingest.de.sentry.io https://*.posthog.com https://pokeapi.co https://beta.pokeapi.co https://api.tcgdex.net https://raw.githubusercontent.com`,
  "worker-src 'self' blob: data:",
  "frame-ancestors 'none'",
].join('; ');

const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), interest-cohort=()' },
  { key: 'X-DNS-Prefetch-Control', value: 'on' },
  { key: 'Content-Security-Policy', value: csp },
];

// These routes render public, locale-keyed content. They still use request
// headers for the current locale, so Next classifies them as dynamic; the
// Vercel-specific directive lets the CDN reuse the complete response without
// enabling browser caching. Personalized/account routes are intentionally not
// listed here.
const publicPageCacheHeader = {
  key: 'Vercel-CDN-Cache-Control',
  value: 'public, s-maxage=3600, stale-while-revalidate=86400',
};

const publicPageCacheRoutes = [
  '/:locale(en|fr|es|de|it|ja|ko|zh)/pokemon/:name',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/pokedex',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/tcg',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/tcg/cards/:id',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/tcg/sets/:setId',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/tcg/deck-builder',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/moves',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/moves/:name',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/abilities',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/abilities/:name',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/items',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/items/:name',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/types',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/compare',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/compare/:slug',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/guides/:slug',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/blog',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/about',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/faq',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/contact',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/30e-anniversaire',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/nuzlocke',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/breeding',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/ev-iv',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/quiz',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/cookies',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/privacy',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/terms',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/legal',
  '/:locale(en|fr|es|de|it|ja|ko|zh)/u/:handle',
];

const nextConfig: NextConfig = {
  compress: true,
  // Shared domain logic lives in the @primedex/core workspace package.
  transpilePackages: ['@primedex/core'],
  turbopack: {
    root: projectRoot,
  },
  allowedDevOrigins: ['192.168.2.203:3000', 'localhost:3000', 'localhost:4747', '127.0.0.1:4747'],
  experimental: {
    optimizePackageImports: ['framer-motion', '@tanstack/react-query', 'lucide-react', 'recharts', 'sonner', 'cmdk', 'i18next', 'react-i18next'],
    optimizeCss: true,
  },
  images: {
    unoptimized: false,
    formats: ['image/avif', 'image/webp'],
    deviceSizes: [750, 828, 1080, 1200],
    imageSizes: [16, 32, 48, 64, 96, 128, 256],
    minimumCacheTTL: 2592000,
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'raw.githubusercontent.com',
        pathname: '/PokeAPI/**',
      },
      {
        protocol: 'https',
        hostname: 'pokeapi.co',
        pathname: '/media/upload/**',
      },
      {
        protocol: 'https',
        hostname: 'images.scrydex.com',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'www.cardtrader.com',
        pathname: '/uploads/blueprints/image/**',
      },
      {
        protocol: 'https',
        hostname: 'images.pokemontcg.io',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'assets.tcgdex.net',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'images.tcgdex.net',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'tcg.pokemon.com',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'mcdn.pokemon.com',
        pathname: '/image/upload/**',
      },
      {
        protocol: 'https',
        hostname: 'dz3we2x72f7ol.cloudfront.net',
        pathname: '/expansions/30th-celebration/**',
      },
    ],
  },
  async rewrites() {
    return [
      {
        source: '/opengraph-image',
        destination: '/og/lunidex-og.jpg',
      },
      {
        source: '/:locale(en|fr|es|de|it|ja|ko|zh)/:path*',
        destination: '/:path*',
      },
    ];
  },
  async redirects() {
    return [
      {
        source: '/:path*',
        has: [
          {
            type: 'host',
            value:
              '(www\\.lunidex\\.app|primedex\\.vercel\\.app|poke-app-lake\\.vercel\\.app|lunidex-teeflo\\.vercel\\.app|lunidex-teeflo-teeflo\\.vercel\\.app)',
          },
        ],
        destination: 'https://lunidex.app/:path*',
        permanent: true,
      },
      {
        source: '/pt/:path*',
        destination: '/en/:path*',
        permanent: true,
      },
    ];
  },
  async headers() {
    return [
      {
        // Apply security headers to all routes
        source: '/(.*)',
        headers: securityHeaders,
      },
      {
        // A service worker must revalidate on every update check. Otherwise a
        // browser can keep an older worker that still points at removed chunk
        // hashes after a deployment.
        source: '/sw.js',
        headers: [
          { key: 'Cache-Control', value: 'no-store, no-cache, max-age=0, must-revalidate' },
        ],
      },
      {
        // The worker extension is imported by sw.js and should follow the same
        // update policy when its notification behavior changes.
        source: '/push-worker.js',
        headers: [
          { key: 'Cache-Control', value: 'no-store, no-cache, max-age=0, must-revalidate' },
        ],
      },
      {
        // Reset links carry a one-time credential. Never cache these pages or
        // send their URL as a referrer to another resource.
        source: '/auth/:path*',
        headers: [
          { key: 'Cache-Control', value: 'no-store, no-cache, max-age=0, must-revalidate' },
          { key: 'Referrer-Policy', value: 'no-referrer' },
        ],
      },
      {
        // Auth API responses include session state and must never be served
        // from an intermediary cache after a sign-in or sign-out mutation.
        source: '/api/auth/:path*',
        headers: [
          { key: 'Cache-Control', value: 'no-store, no-cache, max-age=0, must-revalidate' },
          { key: 'Referrer-Policy', value: 'no-referrer' },
        ],
      },
      {
        source: '/:locale(en|fr|es|de|it|ja|ko|zh)/api/auth/:path*',
        headers: [
          { key: 'Cache-Control', value: 'no-store, no-cache, max-age=0, must-revalidate' },
          { key: 'Referrer-Policy', value: 'no-referrer' },
        ],
      },
      {
        // Localized API URLs are redirected to their unprefixed canonical
        // endpoint by proxy and must not be treated as public pages.
        source: '/:locale(en|fr|es|de|it|ja|ko|zh)/api/:path*',
        headers: [{ key: 'Cache-Control', value: 'private, no-store' }],
      },
      {
        // Localized routes are the public URLs; the proxy rewrites them to the
        // unprefixed App Router path internally.
        source: '/:locale(en|fr|es|de|it|ja|ko|zh)/auth/:path*',
        headers: [
          { key: 'Cache-Control', value: 'no-store, no-cache, max-age=0, must-revalidate' },
          { key: 'Referrer-Policy', value: 'no-referrer' },
        ],
      },
      {
        // Cache SVG and image assets
        source: '/(.*\\.(?:svg|png|jpg|jpeg|gif|webp|avif|ico))',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=86400, stale-while-revalidate=604800',
          },
        ],
      },
      {
        // The legacy OG alias has no image extension, so it needs the same
        // cache policy as the static JPEG rewrite destination.
        source: '/opengraph-image',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=86400, stale-while-revalidate=604800',
          },
        ],
      },
      {
        // Keep the sitemap index in sync with the six-hour child sitemap
        // refresh window. The specialized /sitemaps/*.xml routes set their
        // own cache headers and are intentionally not matched here.
        source: '/sitemap\\.xml',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, s-maxage=21600, max-age=0, stale-while-revalidate=86400',
          },
        ],
      },
      {
        // Cache robots and AI discovery files
        source: '/(robots\\.txt|llms\\.txt|llms-full\\.txt|ai\\.txt)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, s-maxage=86400, max-age=86400, stale-while-revalidate=604800',
          },
        ],
      },
      {
        // Cache font files
        source: '/(.*\\.(?:woff|woff2|ttf|otf))',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable',
          },
        ],
      },
      ...publicPageCacheRoutes.map((source) => ({
        source,
        headers: [publicPageCacheHeader],
      })),
    ];
  },
};

export default withSentryConfig(withPWA(nextConfig), {
  org: process.env.SENTRY_ORG ?? 'teeflo',
  project: process.env.SENTRY_PROJECT ?? 'lunidex',
  authToken: process.env.SENTRY_AUTH_TOKEN,
  telemetry: false,
  silent: !process.env.CI,
  // Upload server maps without widening the client bundle's source-map set;
  // this keeps frequent builds lighter while preserving server-side errors.
  widenClientFileUpload: false,
  sourcemaps: {
    deleteSourcemapsAfterUpload: true,
  },
  webpack: {
    autoInstrumentServerFunctions: true,
    // The proxy already performs lightweight request routing and Vercel
    // Observability covers its invocation metrics. Keep Sentry for errors and
    // page/server-function traces without tracing every middleware request.
    autoInstrumentMiddleware: false,
    autoInstrumentAppDirectory: true,
    automaticVercelMonitors: true,
  },
  errorHandler: (error) => {
    if (process.env.SENTRY_AUTH_TOKEN) throw error;
    console.warn(`[Sentry] Build integration skipped: ${error.message}`);
  },
});
