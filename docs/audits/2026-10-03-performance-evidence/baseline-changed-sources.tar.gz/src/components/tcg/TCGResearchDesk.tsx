'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useInfiniteQuery, useQuery } from '@tanstack/react-query';
import {
  ChevronDown,
  Grid2X2,
  Grid3X3,
  List,
  Search,
  Sparkles,
  Filter,
  X,
  type LucideIcon,
} from 'lucide-react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import dynamic from 'next/dynamic';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { useMounted } from '@/hooks/useMounted';
import { useTranslation } from '@/lib/i18n';
import { DEFAULT_TCG_CARD_FILTERS, getFilterOptions, isTcgLangLimited, searchCards } from '@/lib/api/tcg';
import { tcgKeys } from '@/lib/api/keys';
import { cn } from '@/lib/utils';
import type { TCGCard, TCGCardFilters, TCGCardViewMode, TCGSet } from '@/types/tcg';
import {
  clearTCGCardSearch,
  getLatestTCGSet,
  isInitialTcgCatalogCompatible,
  parseTCGSearchState,
  resetTCGCardFilters,
  sortTCGSetsNewestFirst,
  serializeTCGSearchState,
} from '@/lib/tcg-research';
import { TCGCardItem } from './TCGCardItem';
import { TCGDataLangBanner } from './TCGUnsupportedLangBanner';
import { usePrimeDexStore } from '@/store/primedex';
import { useShallow } from 'zustand/react/shallow';
import { isTCGCardLanguage, type TCGCardLanguage } from '@/lib/tcg-language';
import { buildTCGSetDisplayNames } from '@/lib/tcg-set-label';

const TCGCardDetailModal = dynamic(
  () => import('./TCGCardDetailModal').then((module) => ({ default: module.TCGCardDetailModal })),
  { ssr: false },
);

// Start the next page while the user still has several rows of cards left to
// browse. TCGdex may need to hydrate card metadata before returning a page, so
// the previous 320px margin could leave the user waiting at the end of the
// grid on a normal scroll.
const TCG_CATALOG_LOAD_AHEAD_PX = 1600;

const TCGFilters = dynamic(
  () => import('./TCGFilters').then((module) => ({ default: module.TCGFilters })),
  {
    ssr: false,
    loading: () => <div className="h-32 animate-pulse rounded-sm bg-card/40" />,
  },
);

interface TCGResearchDeskProps {
  initialLatestSet?: {
    id: string;
    name: string;
  } | null;
  initialCards?: TCGCard[];
  initialHasMore?: boolean;
  initialLanguage?: string;
}

export function TCGResearchDesk({
  initialLatestSet = null,
  initialCards = [],
  initialHasMore = false,
  initialLanguage = 'en',
}: TCGResearchDeskProps) {
  const { t } = useTranslation();
  const mounted = useMounted();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const {
    tcgOwnedCards,
    tcgWishlistCards,
    tcgBrowseLanguage,
    hasHydrated,
    setTCGBrowseLanguage,
  } = usePrimeDexStore(useShallow((state) => ({
    tcgOwnedCards: state.tcgOwnedCards,
    tcgWishlistCards: state.tcgWishlistCards,
    tcgBrowseLanguage: state.tcgBrowseLanguage,
    hasHydrated: state._hasHydrated,
    setTCGBrowseLanguage: state.setTCGBrowseLanguage,
  })));
  const ownedIds = useMemo(() => new Set(tcgOwnedCards), [tcgOwnedCards]);
  const wishlistIds = useMemo(() => new Set(tcgWishlistCards), [tcgWishlistCards]);
  const parsedState = useMemo(() => parseTCGSearchState(searchParams), [searchParams]);
  const isTCGStateHydrating = !mounted || !hasHydrated;
  const initialTcgLanguage: TCGCardLanguage = isTCGCardLanguage(initialLanguage) ? initialLanguage : 'en';
  // A valid URL parameter is authoritative for this view. Once mounted, the
  // selector effect mirrors it into the independent browse preference; the
  // interface locale is never involved in resolving TCG data.
  const resolvedLang: TCGCardLanguage = mounted && hasHydrated
    ? (parsedState.tcgLang ?? tcgBrowseLanguage)
    : (parsedState.tcgLang ?? initialTcgLanguage);

  useEffect(() => {
    if (!mounted || !hasHydrated || !parsedState.tcgLang || parsedState.tcgLang === tcgBrowseLanguage) return;
    setTCGBrowseLanguage(parsedState.tcgLang);
  }, [hasHydrated, mounted, parsedState.tcgLang, setTCGBrowseLanguage, tcgBrowseLanguage]);

  useEffect(() => {
    // Load the bundled card rules once for the catalog instead of once per card.
    void import('../../styles/pokemon-cards-css.css');
    void import('../../styles/tcg-card-overrides.css');
  }, []);

  const [filters, setFilters] = useState<TCGCardFilters>(() => normalizeFilters({
    ...DEFAULT_TCG_CARD_FILTERS,
    ...parsedState.filters,
  }));
  const [searchTermDraft, setSearchTermDraft] = useState(parsedState.filters.searchTerm ?? '');
  const [viewMode, setViewMode] = useState<TCGCardViewMode>(() => parsedState.viewMode);
  const [selectedCard, setSelectedCard] = useState<TCGCard | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const didSyncUrlRef = useRef(false);
  const [hasUserEditedFilters, setHasUserEditedFilters] = useState(Boolean(
    parsedState.filters.selectedSet
    || parsedState.filters.searchTerm
    || parsedState.filters.selectedRarity
    || (parsedState.filters.selectedTypes?.length ?? 0) > 0
    || parsedState.filters.selectedPhase
    || (parsedState.filters.selectedTrainerTypes?.length ?? 0) > 0
    || (parsedState.filters.selectedEnergyTypes?.length ?? 0) > 0
    || typeof parsedState.filters.minHp === 'number'
    || typeof parsedState.filters.maxHp === 'number'
    || parsedState.filters.illustrator
    || parsedState.filters.regulationMark
    || (parsedState.filters.legalities?.length ?? 0) > 0
    || typeof parsedState.filters.priceMin === 'number'
    || typeof parsedState.filters.priceMax === 'number'
    || parsedState.filters.releaseStart
    || parsedState.filters.releaseEnd
    || (parsedState.filters.ownedState && parsedState.filters.ownedState !== 'all')
  ));

  useEffect(() => {
    setViewMode(parsedState.viewMode);
  }, [parsedState.viewMode]);

  const normalizedFilters = useMemo(() => normalizeFilters(filters), [filters]);

  const {
    data: filterOptions,
    isError: isFilterOptionsError,
    refetch: refetchFilterOptions,
  } = useQuery({
    queryKey: tcgKeys.filterOptions(resolvedLang),
    queryFn: () => getFilterOptions(resolvedLang),
    staleTime: 60 * 60 * 1000,
    enabled: mounted && hasHydrated,
  });

  const setOptions = useMemo(() => {
    return sortTCGSetsNewestFirst(filterOptions?.sets ?? []);
  }, [filterOptions?.sets]);

  const setDisplayNames = useMemo(() => buildTCGSetDisplayNames(setOptions), [setOptions]);

  const latestSet = getLatestTCGSet(setOptions);
  const latestSetId = latestSet?.id ?? null;
  const initialLanguageIsResolved = Boolean(parsedState.tcgLang) || !isTCGStateHydrating;
  const usableInitialLatestSet = initialLanguageIsResolved
    && initialLanguage === resolvedLang
    && !isTcgLangLimited(resolvedLang)
    ? initialLatestSet
    : null;
  const provisionalInitialLatestSet = !parsedState.tcgLang && isTCGStateHydrating
    ? initialLatestSet
    : null;
  const defaultLatestSet = usableInitialLatestSet ?? provisionalInitialLatestSet ?? latestSet;
  const defaultSetId = defaultLatestSet?.id ?? null;
  const latestSetFallbackId = usableInitialLatestSet?.id ?? latestSetId ?? null;
  const latestSetFallbackName = defaultLatestSet?.name ?? t('tcg.unknown');
  const isResolvingDefaultSet = !hasUserEditedFilters
    && !normalizedFilters.selectedSet
    && (!initialLanguageIsResolved || !defaultSetId);
  const effectiveFilters = useMemo(() => normalizeFilters({
    ...normalizedFilters,
    selectedSet: normalizedFilters.selectedSet ?? (hasUserEditedFilters ? null : defaultSetId),
  }), [defaultSetId, hasUserEditedFilters, normalizedFilters]);
  const urlFilters = normalizedFilters;
  const selectedSet = setOptions.find((set) => set.id === effectiveFilters.selectedSet);
  const activeSetName = effectiveFilters.selectedSet
    ? selectedSet?.name ?? (defaultLatestSet?.id === effectiveFilters.selectedSet ? defaultLatestSet.name : effectiveFilters.selectedSet)
    : hasUserEditedFilters
      ? null
      : latestSetFallbackName;

  useEffect(() => {
    setSearchTermDraft(effectiveFilters.searchTerm ?? '');
  }, [effectiveFilters.searchTerm]);

  useEffect(() => {
    // A set id is only meaningful inside the language-specific TCGdex catalog.
    // If the user changes language and that catalog does not contain the
    // previously selected set, clear the stale URL/filter value instead of
    // querying an unrelated fallback set with zero results.
    if (!mounted || !hasHydrated || !filterOptions || setOptions.length === 0 || !filters.selectedSet) return;
    if (setOptions.some((set) => set.id === filters.selectedSet)) return;

    setFilters((current) => {
      if (current.selectedSet !== filters.selectedSet) return current;
      return normalizeFilters({ ...current, selectedSet: null });
    });
    setHasUserEditedFilters(true);
  }, [filterOptions, filters.selectedSet, hasHydrated, mounted, setOptions]);

  useEffect(() => {
    if (!mounted || !hasHydrated) return;
    // The parsed URL already represents the initial state. Avoid replacing it
    // on first hydration with serialized defaults (sort/order/tcgLang), which
    // causes a same-route navigation and can duplicate head metadata in the
    // browser. Subsequent filter/view changes still update the shareable URL.
    if (!didSyncUrlRef.current) {
      didSyncUrlRef.current = true;
      return;
    }
    const query = serializeTCGSearchState({
      filters: urlFilters,
      viewMode,
      compare: [],
      tcgLang: resolvedLang,
    });
    const current = searchParams.toString();
    if (query === current) return;
    router.replace(query ? `${pathname}?${query}` : pathname, { scroll: false });
  }, [hasHydrated, mounted, pathname, resolvedLang, router, searchParams, urlFilters, viewMode]);

  const ownershipQueryKey = effectiveFilters.ownedState && effectiveFilters.ownedState !== 'all'
    ? { owned: tcgOwnedCards, wishlist: tcgWishlistCards }
    : undefined;
  const initialCatalogData = useMemo(() => ({
    pages: [{ cards: initialCards, hasMore: initialHasMore }],
    pageParams: [1],
  }), [initialCards, initialHasMore]);
  const canUseInitialCatalog = isInitialTcgCatalogCompatible(
    effectiveFilters,
    (usableInitialLatestSet ?? provisionalInitialLatestSet)?.id,
    initialLanguage,
    resolvedLang,
    initialCards.length > 0,
  );

  const {
    data: cardsData,
    isLoading,
    isFetching,
    isError,
    hasNextPage,
    fetchNextPage,
    isFetchingNextPage,
  } = useInfiniteQuery({
    queryKey: tcgKeys.catalog(effectiveFilters, resolvedLang, 24, ownershipQueryKey),
    queryFn: async ({ pageParam, signal }) => searchCards(effectiveFilters, resolvedLang, pageParam, 24, signal, ownedIds, wishlistIds, false),
    initialPageParam: 1,
    getNextPageParam: (lastPage, pages) => lastPage.hasMore ? pages.length + 1 : undefined,
    enabled: mounted && hasHydrated && !isResolvingDefaultSet,
    staleTime: 5 * 60 * 1000,
    initialData: canUseInitialCatalog ? initialCatalogData : undefined,
  });

  const cards = useMemo(() => cardsData?.pages.flatMap((page) => page.cards) ?? [], [cardsData]);
  const totalCards = cards.length;
  const loadMoreRef = useRef<HTMLButtonElement | null>(null);
  const visibleCards = cards;
  const sortValue = `${effectiveFilters.sortBy ?? 'id'}-${effectiveFilters.sortOrder ?? 'asc'}`;

  useEffect(() => {
    const loadMoreButton = loadMoreRef.current;
    if (!loadMoreButton || !hasNextPage || isFetchingNextPage) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          void fetchNextPage();
        }
      },
      { rootMargin: `${TCG_CATALOG_LOAD_AHEAD_PX}px 0px` },
    );

    observer.observe(loadMoreButton);
    return () => observer.disconnect();
  }, [fetchNextPage, hasNextPage, isFetchingNextPage, totalCards]);

  // Search drives the query key, so every keystroke would otherwise fire a
  // fresh upstream request and a router.replace. Coalesce edits for 300 ms.
  const searchTermTimerRef = useRef<number | null>(null);
  const effectiveFiltersRef = useRef(effectiveFilters);
  effectiveFiltersRef.current = effectiveFilters;
  const cancelPendingSearch = useCallback(() => {
    if (searchTermTimerRef.current !== null) {
      window.clearTimeout(searchTermTimerRef.current);
      searchTermTimerRef.current = null;
    }
  }, []);
  const updateFilters = useCallback((next: TCGCardFilters) => {
    cancelPendingSearch();
    setSearchTermDraft(next.searchTerm ?? '');
    setHasUserEditedFilters(true);
    setFilters(normalizeFilters(next));
  }, [cancelPendingSearch]);
  useEffect(() => cancelPendingSearch, [cancelPendingSearch]);
  const updateSearchTerm = useCallback((value: string) => {
    setSearchTermDraft(value);
    setHasUserEditedFilters(true);
    cancelPendingSearch();
    searchTermTimerRef.current = window.setTimeout(() => {
      searchTermTimerRef.current = null;
      updateFilters({ ...effectiveFiltersRef.current, searchTerm: value.trim() ? value : undefined });
    }, 300);
  }, [cancelPendingSearch, updateFilters]);

  const clearFilters = useCallback(() => {
    cancelPendingSearch();
    setSearchTermDraft('');
    setHasUserEditedFilters(false);
    setFilters(resetTCGCardFilters(latestSetFallbackId));
  }, [cancelPendingSearch, latestSetFallbackId]);

  const tryEnglish = useCallback(() => {
    setTCGBrowseLanguage('en');
    const params = new URLSearchParams(searchParams.toString());
    params.set('tcgLang', 'en');
    router.replace(`${pathname}?${params.toString()}`, { scroll: false });
  }, [pathname, router, searchParams, setTCGBrowseLanguage]);

  const openCard = useCallback((card: TCGCard) => {
    setSelectedCard(card);
    setIsModalOpen(true);
  }, []);

  const openFilters = useCallback(() => {
    setIsFiltersOpen(true);
  }, []);

  const applyQuickPreset = useCallback((preset: 'latest' | 'pikachu') => {
    cancelPendingSearch();

    const resetQuickPresetFilters = (current: TCGCardFilters, next: Partial<TCGCardFilters>): TCGCardFilters => normalizeFilters({
      ...current,
      searchTerm: undefined,
      selectedSet: null,
      selectedCategory: 'all',
      selectedRarity: null,
      selectedTypes: [],
      selectedPhase: null,
      selectedTrainerTypes: [],
      selectedEnergyTypes: [],
      minHp: undefined,
      maxHp: undefined,
      illustrator: undefined,
      regulationMark: undefined,
      legalities: [],
      priceMin: undefined,
      priceMax: undefined,
      releaseStart: undefined,
      releaseEnd: undefined,
      ownedState: 'all',
      ...next,
    });

    if (preset === 'latest') {
      setSearchTermDraft('');
      setHasUserEditedFilters(Boolean(latestSetFallbackId));
      setFilters((current) => resetQuickPresetFilters(current, {
        selectedSet: latestSetFallbackId,
      }));
      return;
    }

    setHasUserEditedFilters(true);
    setSearchTermDraft('Pikachu');
    setFilters((current) => resetQuickPresetFilters(current, {
      searchTerm: 'Pikachu',
    }));
  }, [cancelPendingSearch, latestSetFallbackId]);

  const activeFilterChips: Array<{ id: string; label: string; next: TCGCardFilters }> = [];
  const addFilterChip = (id: string, label: string, next: TCGCardFilters) => {
    activeFilterChips.push({ id, label, next });
  };
  if (effectiveFilters.selectedSet) addFilterChip('set', `${t('tcg.filter_set')}: ${activeSetName ?? effectiveFilters.selectedSet}`, { ...effectiveFilters, selectedSet: null });
  if (effectiveFilters.selectedCategory && effectiveFilters.selectedCategory !== 'all') addFilterChip('category', `${t('tcg.filter_category', { defaultValue: 'Category' })}: ${effectiveFilters.selectedCategory}`, { ...effectiveFilters, selectedCategory: 'all' });
  if (effectiveFilters.selectedRarity) addFilterChip('rarity', `${t('tcg.filter_rarity')}: ${effectiveFilters.selectedRarity}`, { ...effectiveFilters, selectedRarity: null });
  for (const type of effectiveFilters.selectedTypes ?? []) addFilterChip(`type-${type}`, `${t(`types.${type}`, { defaultValue: type })}`, { ...effectiveFilters, selectedTypes: (effectiveFilters.selectedTypes ?? []).filter((value) => value !== type) });
  if (effectiveFilters.selectedPhase) addFilterChip('phase', `${t('tcg.filter_phase', { defaultValue: 'Stage' })}: ${effectiveFilters.selectedPhase}`, { ...effectiveFilters, selectedPhase: null });
  for (const type of effectiveFilters.selectedTrainerTypes ?? []) addFilterChip(`trainer-${type}`, `${t('tcg.filter_trainer_type', { defaultValue: 'Trainer' })}: ${type}`, { ...effectiveFilters, selectedTrainerTypes: (effectiveFilters.selectedTrainerTypes ?? []).filter((value) => value !== type) });
  for (const type of effectiveFilters.selectedEnergyTypes ?? []) addFilterChip(`energy-${type}`, `${t('tcg.filter_energy_type', { defaultValue: 'Energy' })}: ${type}`, { ...effectiveFilters, selectedEnergyTypes: (effectiveFilters.selectedEnergyTypes ?? []).filter((value) => value !== type) });
  if (typeof effectiveFilters.minHp === 'number') addFilterChip('min-hp', `${t('tcg.filter_min_hp', { defaultValue: 'Min HP' })}: ${effectiveFilters.minHp}`, { ...effectiveFilters, minHp: undefined });
  if (typeof effectiveFilters.maxHp === 'number') addFilterChip('max-hp', `${t('tcg.filter_max_hp', { defaultValue: 'Max HP' })}: ${effectiveFilters.maxHp}`, { ...effectiveFilters, maxHp: undefined });
  if (effectiveFilters.illustrator) addFilterChip('illustrator', `${t('tcg.illustrator')}: ${effectiveFilters.illustrator}`, { ...effectiveFilters, illustrator: undefined });
  if (effectiveFilters.regulationMark) addFilterChip('regulation', `${t('tcg.filter_regulation', { defaultValue: 'Regulation mark' })}: ${effectiveFilters.regulationMark}`, { ...effectiveFilters, regulationMark: undefined });
  for (const legality of effectiveFilters.legalities ?? []) addFilterChip(`legality-${legality}`, `${t('tcg.filter_legality', { defaultValue: 'Legality' })}: ${legality}`, { ...effectiveFilters, legalities: (effectiveFilters.legalities ?? []).filter((value) => value !== legality) });
  if (typeof effectiveFilters.priceMin === 'number') addFilterChip('min-price', `${t('tcg.price_min')}: ${effectiveFilters.priceMin}`, { ...effectiveFilters, priceMin: undefined });
  if (typeof effectiveFilters.priceMax === 'number') addFilterChip('max-price', `${t('tcg.filter_price_max', { defaultValue: 'Max price' })}: ${effectiveFilters.priceMax}`, { ...effectiveFilters, priceMax: undefined });
  if (effectiveFilters.releaseStart) addFilterChip('release-start', `${t('tcg.release_start')}: ${effectiveFilters.releaseStart}`, { ...effectiveFilters, releaseStart: undefined });
  if (effectiveFilters.releaseEnd) addFilterChip('release-end', `${t('tcg.filter_release_end', { defaultValue: 'Released before' })}: ${effectiveFilters.releaseEnd}`, { ...effectiveFilters, releaseEnd: undefined });
  if (effectiveFilters.ownedState && effectiveFilters.ownedState !== 'all') addFilterChip('owned-state', `${t('tcg.filter_owned_state', { defaultValue: 'Collection' })}: ${effectiveFilters.ownedState}`, { ...effectiveFilters, ownedState: 'all' });

  return (
    <div className="space-y-6 pb-24">
      <TCGDataLangBanner resolvedLang={resolvedLang} onTryEnglish={tryEnglish} />
      <DiscoveryHero
        title={t('tcg.page_title')}
        subtitle={t('tcg.discover_subtitle')}
        searchTerm={searchTermDraft}
        collections={setOptions}
        collectionLabels={setDisplayNames}
        selectedCollectionId={effectiveFilters.selectedSet ?? null}
        sortValue={sortValue}
        isCollectionOptionsLoading={isTCGStateHydrating || isResolvingDefaultSet || !filterOptions}
        onCollectionChange={(selectedSet) => {
          updateFilters({
            ...effectiveFilters,
            selectedSet,
          });
        }}
        onSortChange={(sortBy, sortOrder) => {
          updateFilters({
            ...effectiveFilters,
            sortBy,
            sortOrder,
          });
        }}
        onSearchChange={(value) => updateSearchTerm(value)}
        onClearSearch={() => updateFilters(clearTCGCardSearch(effectiveFilters, latestSetFallbackId))}
        onOpenFilters={openFilters}
      />

      {activeFilterChips.length > 0 ? (
        <div className="flex flex-wrap items-center gap-2" role="region" aria-label={t('tcg.filters')}>
          <span className="text-[10px] font-black uppercase tracking-[0.12em] text-foreground/45">{t('tcg.filters')}</span>
          {activeFilterChips.map((chip) => (
            <button
              key={chip.id}
              type="button"
              onClick={() => updateFilters(chip.next)}
              aria-label={`${t('tcg.clear')}: ${chip.label}`}
              className="inline-flex min-h-11 items-center gap-1.5 rounded-sm border border-primary/25 bg-primary/8 px-2.5 text-xs font-bold text-primary hover:bg-primary/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60"
            >
              <span>{chip.label}</span>
              <X aria-hidden="true" className="h-3.5 w-3.5" />
            </button>
          ))}
          <button
            type="button"
            onClick={clearFilters}
            className="min-h-11 px-2 text-xs font-bold text-foreground/55 underline-offset-4 hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60"
          >
            {t('tcg.clear')}
          </button>
        </div>
      ) : null}

      <div className="space-y-4">
        <section className="min-w-0 space-y-4" aria-labelledby="tcg-results-title">
          <h2 id="tcg-results-title" className="sr-only">
            {t('tcg.results_heading', { defaultValue: 'Catalog results' })}
          </h2>
          {!isTCGStateHydrating && !isResolvingDefaultSet ? (
            <ResultSummary
              count={totalCards}
              activeSetName={activeSetName}
              isFetching={isFetching}
            />
          ) : null}

          {isTCGStateHydrating ? (
            <CardGridSkeleton viewMode={viewMode} />
          ) : isResolvingDefaultSet ? (
            isFilterOptionsError || filterOptions ? (
              <div className="rounded-sm border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-foreground/80" role="alert">
                <p>{t('tcg.activation.sets_load_error', { defaultValue: 'Unable to load sets right now.' })}</p>
                <button
                  type="button"
                  onClick={() => void refetchFilterOptions()}
                  className="mt-3 inline-flex min-h-11 items-center rounded-sm border border-primary/40 px-4 font-bold text-primary hover:bg-primary/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60"
                >
                  {t('common.retry', { defaultValue: 'Retry' })}
                </button>
              </div>
            ) : (
              <CardGridSkeleton viewMode={viewMode} />
            )
          ) : isLoading ? (
            <CardGridSkeleton viewMode={viewMode} />
          ) : isError ? (
            <p role="alert" className="rounded-sm border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-foreground/80">
              {t('tcg.catalog_load_error', { defaultValue: 'Unable to load cards. Please try again.' })}
            </p>
          ) : cards.length > 0 ? (
            <>
              <CardResults
                cards={visibleCards}
                onCardClick={openCard}
                viewMode={viewMode}
                tcgLanguage={resolvedLang}
              />
              {hasNextPage && (
                <button
                  ref={loadMoreRef}
                  type="button"
                  onClick={() => void fetchNextPage()}
                  disabled={isFetchingNextPage}
                  className="mx-auto flex min-h-11 items-center justify-center rounded-sm border border-border/45 bg-card/55 px-5 text-[11px] font-black uppercase tracking-[0.18em] text-foreground/60 transition-colors hover:border-primary/35 hover:bg-primary/10 hover:text-primary"
                >
                  {isFetchingNextPage ? t('tcg.refreshing', { defaultValue: 'Loading…' }) : t('tcg.load_more_cards', { defaultValue: 'Load more cards' })}
                </button>
              )}
            </>
          ) : (
            <EmptyState
              onClear={clearFilters}
              onLatest={() => applyQuickPreset('latest')}
              onPikachu={() => applyQuickPreset('pikachu')}
              language={resolvedLang}
              onTryEnglish={tryEnglish}
            />
          )}
        </section>
      </div>

      <Sheet open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
        <SheetContent side="right" className="w-[92vw] max-w-[480px] p-0">
          <SheetHeader className="border-b border-border/50 px-5 py-4">
            <SheetTitle className="flex items-center gap-2 text-base font-black uppercase tracking-[0.2em]">
              <Filter className="h-4 w-4 text-primary" />
              {t('tcg.filters')}
            </SheetTitle>
          </SheetHeader>
          <div className="max-h-[calc(100dvh-4.5rem)] overflow-y-auto p-4 space-y-4">
            <button
              type="button"
              onClick={() => {
                applyQuickPreset('latest');
                setIsFiltersOpen(false);
              }}
              className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-sm border border-border/50 bg-card/50 px-4 text-[11px] font-black uppercase tracking-[0.18em] text-foreground/60 transition-colors hover:border-primary/25 hover:bg-primary/10 hover:text-primary"
            >
              <Sparkles className="h-3.5 w-3.5" />
              {t('tcg.latest_cards')}
            </button>
            <ViewModeSelector value={viewMode} onChange={setViewMode} />
            <TCGFilters
              mode="advanced"
              filters={effectiveFilters}
              onChange={updateFilters}
              autoApplyInitialSet={false}
              language={resolvedLang}
            />
          </div>
        </SheetContent>
      </Sheet>

      {isModalOpen && (
        <TCGCardDetailModal
          card={selectedCard}
          isOpen
          onClose={() => setIsModalOpen(false)}
          tcgLanguage={resolvedLang}
        />
      )}
    </div>
  );
}

function DiscoveryHero({
  title,
  subtitle,
  searchTerm,
  collections,
  collectionLabels,
  selectedCollectionId,
  sortValue,
  isCollectionOptionsLoading,
  onCollectionChange,
  onSortChange,
  onSearchChange,
  onClearSearch,
  onOpenFilters,
}: {
  title: string;
  subtitle: string;
  searchTerm: string;
  collections: TCGSet[];
  collectionLabels: Map<string, string>;
  selectedCollectionId: string | null;
  sortValue: string;
  isCollectionOptionsLoading: boolean;
  onCollectionChange: (setId: string | null) => void;
  onSortChange: (sortBy: NonNullable<TCGCardFilters['sortBy']>, sortOrder: NonNullable<TCGCardFilters['sortOrder']>) => void;
  onSearchChange: (value: string) => void;
  onClearSearch: () => void;
  onOpenFilters: () => void;
}) {
  const { t } = useTranslation();

  return (
    <section className="rounded-sm border border-border/35 bg-card/20 p-4 sm:p-5">
      <div className="space-y-3">
        <div>
          <h1 className="text-2xl font-black leading-tight tracking-tight sm:text-3xl">{title}</h1>
          <p className="mt-1 max-w-2xl text-sm leading-6 text-foreground/55">{subtitle}</p>
        </div>
        <div className="relative isolate">
          <div className="pointer-events-none absolute left-3 top-1/2 z-10 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-sm border border-border/45 bg-card/75 text-primary/80 shadow-[0_10px_24px_-18px_rgba(0,0,0,0.45)]">
            <Search className="h-4 w-4" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(event) => onSearchChange(event.target.value)}
            placeholder={t('tcg.search_placeholder')}
            className="h-14 w-full rounded-[1.25rem] border border-border/55 bg-card/55 pl-14 pr-4 text-sm font-semibold text-foreground placeholder:text-foreground/30 transition-all focus:border-primary/40 focus:outline-none focus:ring-2 focus:ring-primary/15"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-full sm:w-auto sm:min-w-48 sm:max-w-[20rem]">
            <Sparkles className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-primary" aria-hidden="true" />
            {isCollectionOptionsLoading ? (
              <div className="glass-control flex min-h-11 items-center px-3 pl-9 text-sm font-semibold text-foreground/50" aria-busy="true" aria-label={t('tcg.filter_set')}>
                {t('tcg.collection_loading')}
              </div>
            ) : (
              <select
                value={selectedCollectionId ?? ''}
                onChange={(event) => onCollectionChange(event.target.value || null)}
                className="glass-control min-h-11 w-full cursor-pointer appearance-none px-3 pl-9 pr-8 text-sm font-semibold transition-colors hover:border-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25"
                aria-label={t('tcg.filter_set')}
              >
                <option value="">{t('tcg.all_collections')}</option>
                {collections.map((collection) => (
                  <option key={collection.id} value={collection.id}>
                    {collectionLabels.get(collection.id) ?? collection.name}
                  </option>
                ))}
              </select>
            )}
            <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-foreground/55" aria-hidden="true" />
          </div>
          <div className="w-full sm:w-auto sm:min-w-48 sm:max-w-[20rem]">
            <div className="relative overflow-hidden rounded-sm">
              <select
                value={sortValue}
                onChange={(event) => {
                  const [sortBy, sortOrder] = event.target.value.split('-') as [
                    NonNullable<TCGCardFilters['sortBy']>,
                    NonNullable<TCGCardFilters['sortOrder']>,
                  ];
                  onSortChange(sortBy, sortOrder);
                }}
                className="h-11 w-full appearance-none rounded-sm border border-border/50 bg-card/50 px-4 pr-11 text-sm font-semibold text-foreground/75 transition-colors hover:border-primary/25 hover:bg-primary/10 hover:text-primary focus:border-primary/50 focus:outline-none focus:ring-4 focus:ring-primary/10"
                aria-label={t('tcg.sort_label')}
              >
                <option value="name-asc">{t('tcg.sort_name_asc')}</option>
                <option value="name-desc">{t('tcg.sort_name_desc')}</option>
                <option value="number-asc">{t('tcg.sort_number_asc')}</option>
                <option value="number-desc">{t('tcg.sort_number_desc')}</option>
                <option value="id-asc">{t('tcg.sort_id_asc')}</option>
                <option value="id-desc">{t('tcg.sort_id_desc')}</option>
                <option value="hp-desc">{t('tcg.sort_hp_desc')}</option>
                <option value="hp-asc">{t('tcg.sort_hp_asc')}</option>
                <option value="rarity-asc">{t('tcg.sort_rarity_asc')}</option>
                <option value="rarity-desc">{t('tcg.sort_rarity_desc')}</option>
                <option value="marketPrice-asc">{t('tcg.sort_price_asc')}</option>
                <option value="marketPrice-desc">{t('tcg.sort_price_desc')}</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-4">
                <ChevronDown className="h-4 w-4 text-foreground/30" />
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenFilters}
            className="inline-flex min-h-11 items-center gap-2 rounded-sm border border-primary/25 bg-primary/10 px-4 text-[11px] font-black uppercase tracking-[0.14em] text-primary transition-colors hover:bg-primary/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/70"
          >
            <Filter className="h-3.5 w-3.5" />
            {t('tcg.filters')}
          </button>
          {searchTerm && (
            <button
              type="button"
              onClick={onClearSearch}
              className="inline-flex h-11 items-center gap-2 rounded-sm border border-border/50 bg-card/50 px-4 text-[11px] font-black uppercase tracking-[0.18em] text-foreground/45 transition-colors hover:text-[var(--action-favorite)]"
            >
              {t('tcg.clear')}
            </button>
          )}
        </div>

      </div>
    </section>
  );
}

function ResultSummary({
  count,
  activeSetName,
  isFetching,
}: {
  count: number;
  activeSetName: string | null;
  isFetching: boolean;
}) {
  const { t } = useTranslation();
  return (
    <div className="rounded-[1.4rem] border border-border/50 bg-card/45 px-4 py-3">
      <div className="space-y-1">
        <div className="text-[11px] font-black uppercase tracking-[0.2em] text-foreground/35">
          {isFetching ? t('tcg.refreshing') : t('tcg.cards_found')}
        </div>
        <div className="text-sm font-semibold text-foreground/70">
          {activeSetName
            ? t('tcg.card_count_in_set', { count, set: activeSetName })
            : t('tcg.results_count', { count })
          }
        </div>
      </div>
    </div>
  );
}

function CardResults({
  cards,
  onCardClick,
  viewMode,
  tcgLanguage,
}: {
  cards: TCGCard[];
  onCardClick: (card: TCGCard) => void;
  viewMode: TCGCardViewMode;
  tcgLanguage: TCGCardLanguage;
}) {
  const isList = viewMode === 'table';
  const gridClassName = isList
    ? 'grid grid-cols-1 gap-4'
    : viewMode === 'scan'
      ? 'grid grid-cols-2 gap-2'
      : 'grid grid-cols-2 gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-4';

  return (
    <div className={gridClassName}>
      {cards.map((card, index) => (
        <TCGCardItem
          key={card.id}
          card={card}
          index={index}
          onClick={onCardClick}
          variant={isList ? 'list' : 'default'}
          tcgLanguage={tcgLanguage}
        />
      ))}
    </div>
  );
}

function ViewModeSelector({
  value,
  onChange,
}: {
  value: TCGCardViewMode;
  onChange: (value: TCGCardViewMode) => void;
}) {
  const { t } = useTranslation();
  const options: Array<{ value: TCGCardViewMode; label: string; Icon: LucideIcon }> = [
    { value: 'table', label: t('tcg.list_view'), Icon: List },
    { value: 'scan', label: t('tcg.grid_2_view'), Icon: Grid2X2 },
    { value: 'visual', label: t('tcg.grid_4_view'), Icon: Grid3X3 },
  ];

  return (
    <fieldset className="rounded-sm border border-border/40 bg-card/35 p-3">
      <legend className="px-1 text-[11px] font-black uppercase tracking-[0.18em] text-foreground/35">
        {t('tcg.view_mode')}
      </legend>
      <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label={t('tcg.view_mode')}>
        {options.map(({ value: optionValue, label, Icon }) => {
          const isActive = value === optionValue;
          return (
            <button
              key={optionValue}
              type="button"
              role="radio"
              aria-checked={isActive}
              onClick={() => onChange(optionValue)}
              className={cn(
                'flex min-h-11 min-w-0 flex-col items-center justify-center gap-1 rounded-sm border px-2 py-2 text-center text-[10px] font-black uppercase leading-tight tracking-[0.08em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/70',
                isActive
                  ? 'border-primary/45 bg-primary/15 text-primary'
                  : 'border-border/45 bg-card/45 text-foreground/55 hover:border-primary/25 hover:bg-primary/10 hover:text-primary',
              )}
            >
              <Icon className="h-4 w-4" aria-hidden="true" />
              <span className="truncate max-w-full">{label}</span>
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}

function EmptyState({
  onClear,
  onLatest,
  onPikachu,
  language,
  onTryEnglish,
}: {
  onClear: () => void;
  onLatest: () => void;
  onPikachu: () => void;
  language: TCGCardLanguage;
  onTryEnglish: () => void;
}) {
  const { t } = useTranslation();
  const isLimited = isTcgLangLimited(language);

  return (
    <div className="flex flex-col items-center justify-center rounded-[1.75rem] border border-dashed border-border/50 bg-card/35 px-6 py-20 text-center">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-sm border border-primary/20 bg-primary/10 text-primary">
          <Sparkles className="h-7 w-7" />
        </div>
      <h2 className="text-2xl font-black uppercase tracking-[0.16em] text-foreground">
        {t('tcg.no_cards')}
      </h2>
      <p className="mt-3 max-w-md text-sm leading-7 text-foreground/50">
        {t('tcg.no_results_hint')}
      </p>
      <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
        {isLimited && (
          <button
            type="button"
            onClick={onTryEnglish}
            className="inline-flex h-11 items-center rounded-sm border border-primary/40 bg-primary/15 px-4 text-[11px] font-black uppercase tracking-[0.18em] text-primary transition-colors hover:border-primary/60 hover:bg-primary/25"
          >
            {t('tcg.try_english')}
          </button>
        )}
        <button
          type="button"
          onClick={onClear}
          className="inline-flex h-11 items-center rounded-sm border border-border/45 bg-card/55 px-4 text-[11px] font-black uppercase tracking-[0.18em] text-foreground/60 transition-colors hover:border-primary/25 hover:bg-primary/10 hover:text-primary"
        >
          {t('tcg.reset_filters')}
        </button>
        <button
          type="button"
          onClick={onLatest}
          className="inline-flex h-11 items-center rounded-sm border border-border/45 bg-card/55 px-4 text-[11px] font-black uppercase tracking-[0.18em] text-foreground/60 transition-colors hover:border-primary/25 hover:bg-primary/10 hover:text-primary"
        >
          {t('tcg.latest_cards')}
        </button>
        <button
          type="button"
          onClick={onPikachu}
          className="inline-flex h-11 items-center rounded-sm border border-border/45 bg-card/55 px-4 text-[11px] font-black uppercase tracking-[0.18em] text-foreground/60 transition-colors hover:border-primary/25 hover:bg-primary/10 hover:text-primary"
        >
          {t('tcg.search_pikachu')}
        </button>
      </div>
    </div>
  );
}

function CardGridSkeleton({ viewMode }: { viewMode: TCGCardViewMode }) {
  const isList = viewMode === 'table';
  const gridClassName = isList
    ? 'grid grid-cols-1 gap-4'
    : viewMode === 'scan'
      ? 'grid grid-cols-2 gap-2'
      : 'grid grid-cols-2 gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-4';

  return (
    <div className={gridClassName}>
      {Array.from({ length: 9 }).map((_, index) => (
        <div
          key={index}
          className={cn(
            'rounded-[1rem] border border-border/40 bg-card/45 animate-pulse',
            isList ? 'h-44' : 'aspect-[2.05/2.88]',
          )}
        />
      ))}
    </div>
  );
}


function normalizeFilters(filters: TCGCardFilters): TCGCardFilters {
  return {
    ...DEFAULT_TCG_CARD_FILTERS,
    ...filters,
    selectedCategory: filters.selectedCategory ?? 'all',
    selectedSet: filters.selectedSet ?? null,
    selectedRarity: filters.selectedRarity ?? null,
    selectedTypes: filters.selectedTypes ?? [],
    selectedPhase: filters.selectedPhase ?? null,
    selectedTrainerTypes: filters.selectedTrainerTypes ?? [],
    selectedEnergyTypes: filters.selectedEnergyTypes ?? [],
    legalities: filters.legalities ?? [],
    ownedState: filters.ownedState ?? 'all',
  };
}
