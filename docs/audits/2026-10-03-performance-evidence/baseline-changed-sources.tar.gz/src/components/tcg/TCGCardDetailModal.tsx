'use client';

import Link from 'next/link';
import dynamic from 'next/dynamic';
import { useEffect, useRef, useState, type ComponentType, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { toast } from '@/lib/toast';
import {
  X,
  Zap,
  Box,
  Brush,
  ExternalLink,
  Activity,
  Info,
  Sparkles,
  Shield,
  ScrollText,
  BadgeDollarSign,
} from 'lucide-react';
import type { TCGCard, TCGCardAbility, TCGCardAttack, TCGCardCategory } from '@/types/tcg';
import { useTranslation } from '@/lib/i18n';
import { useMounted } from '@/hooks/useMounted';
import { useClientLanguage, useLocaleHref } from '@/hooks/useLocaleHref';
import { usePrimeDexStore } from '@/store/primedex';
import { hasSyncAccess, requestSyncAccess } from '@/store/sync-access';
import { getTCGCard } from '@/lib/api/tcg';
import { tcgKeys } from '@/lib/api/keys';
import { getCardMarketValue } from '@/lib/tcg-collection';
import { getCardmarketProductUrl } from '@/lib/tcg-marketplace';
import { cn } from '@/lib/utils';
import { TCGHolographicCard } from './TCGHolographicCard';
import {
  encodeTCGCollectionKey,
  getTCGCollectionCardOwnerships,
  getTCGDefaultPhysicalVariant,
  isTCGCollectionCardOwned,
} from '@/lib/tcg-collections';
import type { TCGCardLanguage } from '@/lib/tcg-language';
import { getTCGRarityLabel } from '@/lib/tcg-labels';
import { TCGCollectionVariantSheet } from './TCGCollectionVariantSheet';
import { getFocusTrapTarget } from '@/lib/focus-management';
import {
  getTCGCardDetailCollectionPresentation,
  getTCGCardOwnershipTogglePresentation,
} from '@/lib/tcg-card-ownership-actions';

// Lazy-load the heavy Recharts-based chart only when the card detail is open.
const PriceChart = dynamic(
  () => import('./PriceChart').then((m) => ({ default: m.PriceChart })),
  { ssr: false, loading: () => <div className="h-48 animate-pulse rounded-xl bg-foreground/5" /> },
);

interface TCGCardDetailModalProps {
  card: TCGCard | null;
  isOpen: boolean;
  onClose: () => void;
  onWishlistAdded?: () => void;
  priority?: boolean;
  tcgLanguage?: TCGCardLanguage;
  collectionKey?: string;
  onOwnershipChange?: (owned: boolean) => void;
}

export function TCGCardDetailModal({
  card,
  isOpen,
  onClose,
  onWishlistAdded,
  priority = true,
  tcgLanguage,
  collectionKey,
  onOwnershipChange,
}: TCGCardDetailModalProps) {
  const { t } = useTranslation();
  const mounted = useMounted();
  const localeHref = useLocaleHref();
  const interfaceLanguage = useClientLanguage();
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const dialogRef = useRef<HTMLElement>(null);
  const store = usePrimeDexStore();
  const addTCGCompare = store.addTCGCompare ?? (() => undefined);
  const removeTCGCompare = store.removeTCGCompare ?? (() => undefined);
  const isTCGCompared = store.isTCGCompared ?? (() => false);
  const toggleTCGOwned = store.toggleTCGOwned ?? (() => undefined);
  const removeTCGCollectionCard = store.removeTCGCollectionCard ?? (() => undefined);
  const setTCGCollectionVariantQuantity = store.setTCGCollectionVariantQuantity ?? (() => undefined);
  const tcgCollections = store.tcgCollections;
  const toggleTCGWishlist = store.toggleTCGWishlist ?? (() => undefined);
  const isTCGOwned = store.isTCGOwned ?? (() => false);
  const isTCGWishlist = store.isTCGWishlist ?? (() => false);
  const browseLanguage = store.tcgBrowseLanguage;
  const displayCurrency = store.tcgDisplayCurrency;
  // Card data follows the independent TCG language, never the interface
  // locale prefix. Collection albums pass their fixed language explicitly.
  const resolvedLang = mounted ? (tcgLanguage ?? browseLanguage) : (tcgLanguage ?? 'en');
  const [isVariantSheetOpen, setIsVariantSheetOpen] = useState(false);

  useEffect(() => {
    void import('../../styles/pokemon-cards-css.css');
    void import('../../styles/tcg-card-overrides.css');
  }, []);

  useEffect(() => {
    if (!isOpen) return;

    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeButtonRef.current?.focus();

    return () => {
      document.body.style.overflow = previousOverflow;
      if (previousFocus?.isConnected) previousFocus.focus();
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        if (!isVariantSheetOpen) onClose();
        return;
      }
      if (event.key !== 'Tab' || isVariantSheetOpen) return;

      const dialog = dialogRef.current;
      if (!dialog) return;
      const focusable = Array.from(dialog.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
      ));
      const activeElement = document.activeElement;
      const destination = getFocusTrapTarget({
        backwards: event.shiftKey,
        focusIsInside: activeElement instanceof HTMLElement && focusable.includes(activeElement),
        focusIsFirst: activeElement === focusable[0],
        focusIsLast: activeElement === focusable[focusable.length - 1],
        focusableCount: focusable.length,
      });
      if (destination) {
        event.preventDefault();
        focusable[destination === 'first' ? 0 : focusable.length - 1]?.focus();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, isVariantSheetOpen, onClose]);

  useEffect(() => {
    if (!isOpen) setIsVariantSheetOpen(false);
  }, [isOpen]);

  const { data: hydratedCard, isFetching } = useQuery({
    queryKey: card ? tcgKeys.card(card.id, resolvedLang) : tcgKeys.card('missing', resolvedLang),
    queryFn: async () => (
      card
        ? getTCGCard(card.id, resolvedLang, undefined, { allowEnglishFallback: false })
        : null
    ),
    enabled: mounted && isOpen && !!card,
    staleTime: 30 * 60 * 1000,
    placeholderData: card ?? undefined,
  });

  if (!mounted || !card || !isOpen) return null;

  const displayCard = hydratedCard ?? card;
  const isHydrating = isFetching && !displayCard.category;
  const titleId = `tcg-card-detail-title-${card.id}`;
  const descriptionId = `tcg-card-detail-description-${card.id}`;
  const totalCards = displayCard.set?.cardCount?.total ?? displayCard.set?.totalCards;
  const category = displayCard.category ?? 'Pokemon';
  const categoryLabel = getCategoryLabel(category, t);
  const effectText = displayCard.effect || displayCard.description || displayCard.flavorText || '';
  const attacks = displayCard.attacks ?? [];
  const abilities = normalizeAbilities(displayCard.abilities);
  const pokemonPageHref = category === 'Pokemon' && displayCard.dexId?.[0]
    ? localeHref(`/pokemon/${displayCard.dexId[0]}`)
    : null;
  const tcgCompareList = store.tcgCompareList ?? [];
  const candidateCollectionKey = displayCard.set?.id
    ? encodeTCGCollectionKey(resolvedLang, displayCard.set.id)
    : null;
  // Catalogue/card pages should keep the existing v1 behaviour when the user
  // has not started that language/set collection yet. An explicit album key,
  // or a known collection in the store, opts into language-scoped ownership;
  // otherwise the action remains a historical (language-less) possession.
  const resolvedCollectionKey = collectionKey
    ?? (candidateCollectionKey && tcgCollections.includes(candidateCollectionKey)
      ? candidateCollectionKey
      : null);
  const compared = isTCGCompared(displayCard.id);
  const owned = resolvedCollectionKey
    ? isTCGCollectionCardOwned(resolvedCollectionKey, displayCard.id, store.tcgCollectionCards)
    : isTCGOwned(displayCard.id);
  const collectionOwnerships = resolvedCollectionKey
    ? getTCGCollectionCardOwnerships(resolvedCollectionKey, store.tcgCollectionCards)
      .filter((ownership) => ownership.cardId === displayCard.id)
    : [];
  const totalOwnedQuantity = collectionOwnerships.reduce((sum, ownership) => sum + ownership.quantity, 0);
  const wishlisted = isTCGWishlist(displayCard.id);
  const marketValue = getCardMarketValue(displayCard, displayCurrency);
  const marketValueLabel = marketValue
    ? (() => {
        try {
          return new Intl.NumberFormat(undefined, {
            style: 'currency',
            currency: marketValue.currency,
            maximumFractionDigits: 2,
          }).format(marketValue.amount);
        } catch {
          return `${marketValue.amount.toFixed(2)} ${marketValue.currency}`;
        }
      })()
    : null;
  const cardmarketHref = getCardmarketProductUrl(displayCard, interfaceLanguage);
  const collectionPresentation = resolvedCollectionKey
    ? getTCGCardDetailCollectionPresentation(owned)
    : null;
  const ownershipPresentation = getTCGCardOwnershipTogglePresentation(owned);

  const handleShareCard = async () => {
    const url = new URL(
      `/tcg/cards/${displayCard.id}?tcgLang=${resolvedLang}`,
      window.location.origin,
    ).toString();
    try {
      await navigator.clipboard.writeText(url);
      toast.success(t('detail.copied'));
    } catch {
      window.prompt(t('detail.copied'), url);
    }
  };

  const handleWishlist = () => {
    if (!hasSyncAccess()) {
      requestSyncAccess();
      return;
    }
    toggleTCGWishlist(displayCard.id);
    if (!wishlisted && !owned) onWishlistAdded?.();
  };

  const handleOwnedToggle = () => {
    if (!hasSyncAccess()) {
      requestSyncAccess();
      return;
    }
    const wasOwned = owned;
    if (!resolvedCollectionKey) {
      toggleTCGOwned(displayCard.id);
    } else if (owned) {
      removeTCGCollectionCard(resolvedCollectionKey, displayCard.id);
    } else {
      const firstKnownVariant = getTCGDefaultPhysicalVariant(displayCard.variants);
      setTCGCollectionVariantQuantity(
        resolvedCollectionKey,
        displayCard.id,
        firstKnownVariant ?? 'unspecified',
        1,
      );
    }

    const nextState = usePrimeDexStore.getState();
    const isNextOwned = resolvedCollectionKey
      ? isTCGCollectionCardOwned(resolvedCollectionKey, displayCard.id, nextState.tcgCollectionCards)
      : nextState.isTCGOwned(displayCard.id);
    if (!wasOwned && isNextOwned) {
      onOwnershipChange?.(true);
      toast.success(t('tcg.collection_card_added', {
        name: displayCard.name,
        defaultValue: `${displayCard.name} added to your collection`,
      }));
    }
  };

  return createPortal(
    <div lang={interfaceLanguage} className="fixed inset-0 z-[300] flex items-center justify-center p-2 sm:p-4 lg:p-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        onClick={onClose}
        aria-hidden="true"
        className="fixed inset-0 bg-muted/45"
      />

      <motion.section
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={descriptionId}
        initial={{ opacity: 0, y: 18, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.24, ease: 'easeOut' }}
        className="glass-surface relative z-[301] flex h-[calc(100dvh-1rem)] w-full max-w-6xl flex-col overflow-hidden rounded-[1.25rem] border-border/70 bg-card text-foreground shadow-[var(--shadow-pixel)] sm:h-[calc(100dvh-2rem)] sm:rounded-[1.5rem] lg:h-[min(88dvh,58rem)]"
      >
        <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-[linear-gradient(180deg,color-mix(in_oklab,var(--primary)_12%,transparent),transparent)]" />
        <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(255,255,255,0.03),transparent_24%,transparent_76%,rgba(0,0,0,0.16))]" />

        <button
          ref={closeButtonRef}
          type="button"
          onClick={onClose}
          className="touch-target absolute right-3 top-3 z-20 inline-flex items-center justify-center rounded-xl border border-border/60 bg-background/70 text-foreground/70 shadow-[var(--shadow-pixel-sm)] backdrop-blur-sm transition-all hover:-translate-y-px hover:bg-card hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 sm:right-4 sm:top-4"
          aria-label={t('common.close')}
          title={t('common.close')}
        >
          <X className="h-5 w-5" />
        </button>

        <div className="relative flex min-h-0 flex-1 flex-col lg:grid lg:grid-cols-[minmax(320px,0.95fr)_minmax(0,1.05fr)]">
          <aside className="relative flex min-h-[17rem] shrink-0 items-center justify-center overflow-hidden border-b border-border/60 bg-gradient-to-b from-primary/10 via-card/70 to-background/30 p-5 sm:min-h-[20rem] sm:p-8 lg:min-h-0 lg:border-b-0 lg:border-r lg:p-10">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_18%,color-mix(in_oklab,var(--primary)_18%,transparent),transparent_48%)]" />
            <div className="pointer-events-none absolute inset-x-10 bottom-8 h-16 rounded-full bg-primary/15 blur-3xl" />

            <div className="relative w-full max-w-[205px] sm:max-w-[270px] lg:max-w-[360px]">
              <TCGHolographicCard
                card={displayCard}
                priority={priority}
                noFrame
                sizes="(min-width: 1024px) 360px, (min-width: 640px) 270px, 205px"
              />

              <div className="mt-4 flex items-center justify-between gap-3 rounded-xl border border-border/45 bg-background/25 px-3 py-2.5 font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">
                <span className="truncate">{displayCard.set?.name || t('tcg.unknown')}</span>
                <span className="shrink-0">#{displayCard.localId}</span>
              </div>
            </div>
          </aside>

          <div className="relative min-h-0 overflow-y-auto p-5 sm:p-8 lg:p-10 scrollbar-premium">
            {isHydrating ? (
              <DetailSkeleton />
            ) : (
              <div className="relative space-y-8">

                {/* ── Identity ─────────────────────────────────────── */}
                <header className="space-y-5">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className={cn('rounded-full border px-3 py-1.5 text-[11px] font-black uppercase tracking-[0.14em]', getCategoryTone(category).badge)}>
                      {categoryLabel}
                    </span>
                    {displayCard.rarity && (
                      <span className="rounded-full border border-border/50 bg-background/30 px-3 py-1.5 text-[11px] font-black uppercase tracking-[0.14em] text-muted-foreground">
                        {getTCGRarityLabel(displayCard.rarity, t)}
                      </span>
                    )}
                    {displayCard.stage && (
                      <span className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">
                        {getStageLabel(displayCard.stage, t)}
                      </span>
                    )}
                    {displayCard.trainerType && (
                      <span className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">
                        {getTrainerTypeLabel(displayCard.trainerType, t)}
                      </span>
                    )}
                    {displayCard.energyType && (
                      <span className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">
                        {getEnergyTypeLabel(displayCard.energyType, t)}
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap items-end gap-x-5 gap-y-3">
                    <h2 id={titleId} className="max-w-[15ch] text-4xl font-display font-black uppercase leading-[0.95] tracking-[-0.03em] text-balance sm:text-5xl xl:text-6xl">
                      {displayCard.name}
                    </h2>
                    {typeof displayCard.hp === 'number' && (
                      <div className="flex items-baseline gap-2 rounded-xl border border-primary/25 bg-primary/10 px-3 py-2">
                        <span className="font-mono text-[10px] font-black uppercase tracking-[0.16em] text-muted-foreground">{t('stats.hp')}</span>
                        <span className="text-3xl font-display font-black leading-none text-primary sm:text-4xl">{displayCard.hp}</span>
                      </div>
                    )}
                  </div>

                  <p id={descriptionId} className="max-w-2xl text-sm leading-6 text-muted-foreground">
                    {effectText || t(attacks.length > 0 || abilities.length > 0 ? 'tcg.detail_description_empty' : 'tcg.detail_empty')}
                  </p>

                  <div className="grid gap-2.5 sm:grid-cols-2 xl:grid-cols-4">
                    <ActionPill
                      active={compared}
                      onClick={() => (compared ? removeTCGCompare(displayCard.id) : addTCGCompare(displayCard.id))}
                      label={compared ? t('tcg.remove_from_compare') : t('tcg.add_to_compare')}
                      badge={compared ? tcgCompareList.length : undefined}
                    />
                    {collectionPresentation ? (
                      <ActionPill
                        active={collectionPresentation.pressed}
                        onClick={() => {
                          if (collectionPresentation.behavior === 'manage-variants') {
                            setIsVariantSheetOpen(true);
                          } else {
                            handleOwnedToggle();
                          }
                        }}
                        label={t(collectionPresentation.labelKey, {
                          defaultValue: collectionPresentation.behavior === 'manage-variants'
                            ? 'Owned variants'
                            : 'Add',
                        })}
                        ariaLabel={t(collectionPresentation.ariaLabelKey, {
                          name: displayCard.name,
                          count: totalOwnedQuantity,
                        })}
                        ariaPressed={collectionPresentation.pressed}
                        badge={totalOwnedQuantity > 0 ? totalOwnedQuantity : undefined}
                        ariaExpanded={collectionPresentation.behavior === 'manage-variants' ? isVariantSheetOpen : undefined}
                        ariaControls={collectionPresentation.behavior === 'manage-variants'
                          ? `tcg-collection-variants-${displayCard.id}`
                          : undefined}
                      />
                    ) : (
                      <ActionPill
                        active={ownershipPresentation.pressed}
                        onClick={handleOwnedToggle}
                        label={t(ownershipPresentation.labelKey)}
                        ariaLabel={t(ownershipPresentation.ariaLabelKey, { name: displayCard.name })}
                        ariaPressed={ownershipPresentation.pressed}
                      />
                    )}
                    <ActionPill active={wishlisted} onClick={handleWishlist} label={t('tcg.mark_wishlist')} />
                    <ActionPill active={false} onClick={handleShareCard} label={t('detail.share')} />
                  </div>
                </header>

                {/* ── Market price ─────────────────────────────────── */}
                <section className="relative overflow-hidden rounded-2xl border border-primary/25 bg-gradient-to-br from-primary/12 via-primary/5 to-background/20">
                  <div className="pointer-events-none absolute -right-10 -top-12 h-32 w-32 rounded-full bg-primary/15 blur-3xl" />
                  <div className="relative flex flex-col gap-5 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <BadgeDollarSign className="h-4 w-4 text-primary" aria-hidden="true" />
                        <p className="text-[11px] font-black uppercase tracking-[0.18em]">
                          {t('tcg.market_price')}
                        </p>
                      </div>
                      <div className="mt-2 flex flex-wrap items-baseline gap-x-3 gap-y-1">
                        <p className="text-3xl font-display font-black leading-none tracking-[-0.02em] text-primary">
                          {marketValueLabel ?? '—'}
                        </p>
                        {marketValue && (
                          <p className="font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
                            via {marketValue.currency === 'EUR' ? 'Cardmarket' : 'TCGplayer'}
                          </p>
                        )}
                      </div>
                    </div>
                    {cardmarketHref && (
                      <a
                        href={cardmarketHref}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="touch-target inline-flex w-full items-center justify-center gap-2 rounded-xl border border-primary/60 bg-primary px-4 text-center text-[11px] font-black uppercase tracking-[0.12em] text-primary-foreground shadow-[var(--shadow-pixel-sm)] transition-all hover:-translate-y-px hover:bg-primary/90 hover:shadow-[var(--shadow-pixel)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-card sm:w-auto"
                      >
                        {t('tcg.view_on_cardmarket')}
                        <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                      </a>
                    )}
                  </div>
                </section>

                {/* ── Card details ─────────────────────────────────── */}
                <section className="space-y-3">
                  <SectionLabel>{t('tcg.expansion')}</SectionLabel>
                  <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                    <InfoItem icon={Box} label={t('tcg.expansion')} value={displayCard.set?.name || t('tcg.unknown')} />
                    <InfoItem icon={Info} label={t('tcg.collector_no')} value={`#${displayCard.localId}${totalCards ? ` / ${totalCards}` : ''}`} />
                    <InfoItem icon={Brush} label={t('tcg.illustrator')} value={displayCard.illustrator || t('tcg.unknown')} />
                    <InfoItem icon={Activity} label={t('tcg.regulation')} value={displayCard.regulationMark || t('tcg.none')} />
                    {pokemonPageHref && (
                      <InfoItem
                        icon={ExternalLink}
                        label={t('tcg.pokemon_page')}
                        value={(
                          <Link href={pokemonPageHref} className="inline-flex items-center gap-1 text-xs font-bold text-primary transition-colors hover:text-primary/80 hover:underline">
                            {t('tcg.open_pokemon_page')}
                          </Link>
                        )}
                      />
                    )}
                  </div>
                </section>

                {/* ── Pokémon ──────────────────────────────────────── */}
                {category === 'Pokemon' && (
                  <section className="space-y-5">
                    <SectionLabel>{t('tcg.card_category_pokemon')}</SectionLabel>

                    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                      <InfoItem icon={Zap} label={t('tcg.pokemon_types')} value={displayCard.types?.join(', ') || t('tcg.none')} />
                      <InfoItem icon={Shield} label={t('tcg.stage')} value={displayCard.stage ? getStageLabel(displayCard.stage, t) : t('tcg.none')} />
                      <InfoItem icon={Sparkles} label={t('tcg.evolves_from')} value={displayCard.evolveFrom || t('tcg.none')} />
                    </div>

                    {(displayCard.weaknesses?.length || displayCard.resistances?.length || displayCard.retreat || displayCard.retreatCost) ? (
                      <div className="grid gap-3 sm:grid-cols-3">
                        <InfoItem icon={Shield} label={t('detail.weaknesses')} value={formatCardList(displayCard.weaknesses, t('tcg.none'))} />
                        <InfoItem icon={Shield} label={t('detail.resistances')} value={formatCardList(displayCard.resistances, t('tcg.none'))} />
                        <InfoItem icon={Zap} label={t('tcg.retreat_cost')} value={formatRetreatCost(displayCard.retreat ?? displayCard.retreatCost ?? 0, t)} />
                      </div>
                    ) : null}

                    {abilities.length > 0 && (
                      <div className="space-y-3">
                        <SectionLabel>{t('tcg.abilities')}</SectionLabel>
                        <div className="space-y-3">
                          {abilities.map((ability, index) => (
                            <EffectPanel
                              key={`${ability.name || 'ability'}-${index}`}
                              icon={Sparkles}
                              title={ability.name || t('tcg.unknown')}
                              text={ability.effect || ability.text || t('tcg.none')}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {attacks.length > 0 && (
                      <div className="space-y-3">
                        <SectionLabel>{t('detail.moveset')}</SectionLabel>
                        <div className="space-y-3">
                          {attacks.map((attack, index) => (
                            <AttackPanel key={`${attack.name || 'attack'}-${index}`} attack={attack} />
                          ))}
                        </div>
                      </div>
                    )}

                    {effectText && (
                      <EffectPanel icon={ScrollText} title={t('tcg.flavor_text')} text={effectText} />
                    )}
                  </section>
                )}

                {/* ── Trainer / Energy ─────────────────────────────── */}
                {(category === 'Trainer' || category === 'Energy') && (
                  <section className="space-y-4">
                    <SectionLabel>{categoryLabel}</SectionLabel>
                    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                      {displayCard.trainerType && (
                        <InfoItem icon={Shield} label={t('tcg.trainer_type')} value={getTrainerTypeLabel(displayCard.trainerType, t)} />
                      )}
                      {displayCard.energyType && (
                        <InfoItem icon={Zap} label={t('tcg.energy_type')} value={getEnergyTypeLabel(displayCard.energyType, t)} />
                      )}
                    </div>
                    {effectText && (
                      <EffectPanel icon={Sparkles} title={t('tcg.effect')} text={effectText} />
                    )}
                  </section>
                )}

                {/* ── Price history chart ──────────────────────────── */}
                <section className="space-y-3">
                  <DeferredPriceChart cardId={displayCard.id} />
                </section>

                {/* ── Footer ───────────────────────────────────────── */}
                <div className="flex justify-end border-t border-border/60 pt-5">
                  <a
                    href={`https://api.tcgdex.net/v2/${resolvedLang}/cards/${displayCard.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="touch-target inline-flex items-center gap-2 rounded-xl border border-border/50 bg-card/60 px-4 text-[11px] font-black uppercase tracking-[0.12em] text-muted-foreground shadow-[var(--shadow-pixel-sm)] transition-all hover:-translate-y-px hover:border-primary/40 hover:bg-primary/10 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-card"
                  >
                    {t('tcg.open_raw_data')}
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </motion.section>

      {resolvedCollectionKey && (
        <TCGCollectionVariantSheet
          card={displayCard}
          collectionKey={resolvedCollectionKey}
          language={resolvedLang}
          open={isVariantSheetOpen}
          onOpenChange={setIsVariantSheetOpen}
          onOwnershipChange={onOwnershipChange}
        />
      )}
    </div>,
    document.body,
  );
}

function DeferredPriceChart({ cardId }: { cardId: string }) {
  const [shouldLoad, setShouldLoad] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;
        setShouldLoad(true);
        observer.disconnect();
      },
      { rootMargin: '160px 0px' },
    );

    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={containerRef} className="min-h-48">
      {shouldLoad ? (
        <PriceChart cardId={cardId} />
      ) : (
        <div className="h-48 animate-pulse rounded-2xl border border-border/55 bg-background/20" aria-hidden="true" />
      )}
    </div>
  );
}

interface InfoItemProps {
  icon: ComponentType<{ className?: string }>;
  label: string;
  value: ReactNode;
}

function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <span className="shrink-0 text-[11px] font-black uppercase tracking-[0.2em] text-muted-foreground">{children}</span>
      <div className="h-px flex-1 bg-border/70" />
    </div>
  );
}

function InfoItem({ icon: Icon, label, value }: InfoItemProps) {
  return (
    <div className="rounded-xl border border-border/55 bg-background/20 p-4 transition-colors hover:border-primary/30 hover:bg-primary/5">
      <div className="mb-1 flex items-center gap-2">
        <Icon className="h-3 w-3 text-primary" />
        <span className="text-[11px] font-black uppercase tracking-widest text-muted-foreground">{label}</span>
      </div>
      <span className="block break-words text-xs font-bold leading-snug text-foreground">
        {value}
      </span>
    </div>
  );
}

function EffectPanel({
  icon: Icon,
  title,
  text,
}: {
  icon: ComponentType<{ className?: string }>;
  title: string;
  text: string;
}) {
  return (
    <div className="glass-card space-y-3 rounded-xl border-border/55 bg-background/20 p-5 sm:p-6">
      <div className="flex items-center gap-2">
        <Icon className="h-4 w-4 text-primary" />
        <h3 className="text-xs font-black uppercase tracking-widest text-primary">
          {title}
        </h3>
      </div>
      <p className="font-body text-sm leading-relaxed text-muted-foreground">{text}</p>
    </div>
  );
}

function AttackPanel({ attack }: { attack: TCGCardAttack }) {
  return (
    <div className="glass-card group rounded-xl border-border/55 bg-background/20 p-5 transition-all hover:bg-primary/5 sm:p-6">
      <div className="mb-2 flex items-start justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex flex-wrap gap-1.5">
            {attack.cost?.map((cost, costIndex) => (
              <span
                key={`${cost}-${costIndex}`}
                className="rounded-full border border-border/60 bg-card/55 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.14em] text-muted-foreground"
              >
                {cost}
              </span>
            ))}
          </div>
          <h4 className="text-base font-display font-black uppercase text-foreground transition-colors group-hover:text-primary">
            {attack.name}
          </h4>
        </div>

        {attack.damage && (
          <span className="text-xl font-display font-black text-muted-foreground">
            {attack.damage}
          </span>
        )}
      </div>

      <p className="font-body text-sm leading-relaxed text-muted-foreground">
        {attack.effect || attack.text || ''}
      </p>
    </div>
  );
}

function DetailSkeleton() {
  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <div className="h-5 w-28 rounded-sm bg-card/65 animate-pulse" />
        <div className="h-12 w-3/4 rounded-sm bg-card/60 animate-pulse" />
        <div className="h-4 w-full rounded-sm bg-card/55 animate-pulse" />
        <div className="h-4 w-5/6 rounded-sm bg-card/55 animate-pulse" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {Array.from({ length: 6 }).map((_, index) => (
          <div key={index} className="h-24 rounded-sm bg-card/50 animate-pulse" />
        ))}
      </div>

      <div className="space-y-3">
        <div className="h-4 w-32 rounded-sm bg-card/60 animate-pulse" />
        <div className="h-28 rounded-sm bg-card/50 animate-pulse" />
        <div className="h-28 rounded-sm bg-card/50 animate-pulse" />
      </div>
    </div>
  );
}

function ActionPill({
  active,
  onClick,
  label,
  ariaLabel,
  ariaPressed,
  badge,
  ariaExpanded,
  ariaControls,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  ariaLabel?: string;
  ariaPressed?: boolean;
  badge?: number;
  ariaExpanded?: boolean;
  ariaControls?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={ariaLabel}
      aria-pressed={ariaPressed}
      aria-expanded={ariaExpanded}
      aria-controls={ariaControls}
      className={cn(
        'touch-target relative w-full rounded-xl border px-3 text-center text-[11px] font-black uppercase tracking-[0.12em] transition-all duration-100 shadow-[var(--shadow-pixel-sm)] hover:-translate-x-px hover:-translate-y-px active:translate-x-0.5 active:translate-y-0.5 active:shadow-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-card',
        active
          ? 'border-primary/60 bg-primary/15 text-primary shadow-[var(--shadow-pixel-sm)]'
          : 'border-border/50 bg-card/50 text-muted-foreground hover:border-primary/40 hover:bg-card/65 hover:text-foreground',
      )}
    >
      {label}
      {typeof badge === 'number' && badge > 0 && (
        <span className="ml-1.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[11px] font-black leading-none text-primary-foreground">
          {badge}
        </span>
      )}
    </button>
  );
}

function getCategoryLabel(category: TCGCardCategory, t: (key: string, options?: { defaultValue?: string }) => string) {
  switch (category) {
    case 'Trainer':
      return t('tcg.card_category_trainer');
    case 'Energy':
      return t('tcg.card_category_energy');
    default:
      return t('tcg.card_category_pokemon');
  }
}

function getCategoryTone(category: TCGCardCategory) {
  switch (category) {
    case 'Trainer':
      return {
        badge: 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:border-amber-400/25 dark:text-amber-200',
      };
    case 'Energy':
      return {
        badge: 'border-cyan-500/30 bg-cyan-500/10 text-cyan-700 dark:border-cyan-400/25 dark:text-cyan-200',
      };
    default:
      return {
        badge: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:border-emerald-400/25 dark:text-emerald-200',
      };
  }
}

function getStageLabel(stage: string, t: (key: string, options?: { defaultValue?: string }) => string) {
  const mapping: Record<string, string> = {
    Basic: 'tcg.phase_basic',
    Stage1: 'tcg.phase_stage_1',
    Stage2: 'tcg.phase_stage_2',
    LevelX: 'tcg.phase_level_x',
    V: 'tcg.phase_v',
    VSTAR: 'tcg.phase_vstar',
    VMAX: 'tcg.phase_vmax',
    EX: 'tcg.phase_ex',
    GX: 'tcg.phase_gx',
    MEGA: 'tcg.phase_mega',
  };

  return mapping[stage] ? t(mapping[stage]) : stage;
}

function getTrainerTypeLabel(type: string, t: (key: string, options?: { defaultValue?: string }) => string) {
  const mapping: Record<string, string> = {
    Supporter: 'tcg.trainer_type_supporter',
    Item: 'tcg.trainer_type_item',
    Stadium: 'tcg.trainer_type_stadium',
    Tool: 'tcg.trainer_type_tool',
    'Ace Spec': 'tcg.trainer_type_ace_spec',
    'Technical Machine': 'tcg.trainer_type_technical_machine',
    'Goldenrod Game Corner': 'tcg.trainer_type_goldenrod_game_corner',
    'Rocket\'s Secret Machine': 'tcg.trainer_type_rockets_secret_machine',
  };

  return mapping[type] ? t(mapping[type]) : type;
}

function getEnergyTypeLabel(type: string, t: (key: string, options?: { defaultValue?: string }) => string) {
  switch (type) {
    case 'Basic':
      return t('tcg.energy_type_basic');
    case 'Special':
      return t('tcg.energy_type_special');
    default:
      return type;
  }
}

function formatCardList(items: { type: string; value: string }[] | undefined, fallback: string) {
  if (!items || items.length === 0) return fallback;
  return items.map((item) => `${item.type} ${item.value}`).join(' · ');
}

function formatRetreatCost(retreat: number, t: (key: string, options?: { defaultValue?: string }) => string) {
  if (!retreat) return t('tcg.none');
  return Array.from({ length: retreat }).map(() => '●').join(' ');
}

function normalizeAbilities(abilities?: TCGCardAbility | TCGCardAbility[]) {
  if (!abilities) return [];
  return Array.isArray(abilities) ? abilities : [abilities];
}
