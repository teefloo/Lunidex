﻿import { graphqlClient } from './client';
import { getCachedData, setCachedData } from './cache';
import { PokemonBasicData, GraphQLPokemonSummary, GraphQLPokemonSearchIndex, GraphQLPokemonMoveData, LocalizedPokemonData, GraphQLMoveData, GraphQLMovePokemonData, GraphQLAbilityData, GraphQLAbilityPokemonData, GraphQLItemData } from '@/types/pokemon';
import { reportFallback } from '@/lib/sentry-observability';

const BATCH_SIZE = 200;
const SEARCH_BATCH_SIZE = 250;
const MOVE_BATCH_SIZE = 250;

const getBatchCacheKey = (base: string, batchIndex: number) => `${base}-batch-${batchIndex}`;

function throwInvalidGraphQLResponse(operation: string): never {
  reportFallback('invalid-response', { feature: 'graphql', operation });
  throw new Error('Invalid GraphQL response');
}

const fetchBatch = async <T>(
  query: string,
  cacheKey: string,
  variables?: Record<string, unknown>,
  signal?: AbortSignal,
): Promise<T[]> => {
  if (signal?.aborted) throw signal.reason ?? new Error('GraphQL batch request aborted');
  const cached = await getCachedData<T[]>(cacheKey);
  if (cached) return cached;

  const { data } = signal
    ? await graphqlClient.post<{ data?: { pokemon_v2_pokemon?: T[] } }>(
      '/graphql/v1beta',
      { query, variables },
      { signal },
    )
    : await graphqlClient.post<{ data?: { pokemon_v2_pokemon?: T[] } }>('/graphql/v1beta', { query, variables });

  if (signal?.aborted) throw signal.reason ?? new Error('GraphQL batch request aborted');
  
  if (!data?.data?.pokemon_v2_pokemon) {
    throwInvalidGraphQLResponse('fetch-batch');
  }
  
  const results = data.data.pokemon_v2_pokemon;
  await setCachedData(cacheKey, results);
  return results;
};

const buildPokemonSummarySelection = () => `
  id
  name
  height
  weight
  pokemon_v2_pokemonspecy {
    generation_id
    pokemon_v2_pokemonspeciesnames(where: {pokemon_v2_language: {name: {_in: ["en", "fr", "es", "de", "it", "ja", "ko", "zh-Hans"]}}}) {
      name
      pokemon_v2_language {
        name
      }
    }
  }
  pokemon_v2_pokemontypes {
    pokemon_v2_type {
      name
    }
  }
`;

export const getPokemonSummarySlice = async (
  limit = 80,
  offset = 0,
): Promise<GraphQLPokemonSummary[]> => {
  const cacheKey = `pokemon-summary-slice-v1-${offset}-${limit}`;
  const cached = await getCachedData<GraphQLPokemonSummary[]>(cacheKey);
  if (cached) return cached;

  const { data } = await graphqlClient.post<{ data?: { pokemon_v2_pokemon?: GraphQLPokemonSummary[] } }>('/graphql/v1beta', {
    query: `
      query GetPokemonSummarySlice($limit: Int!, $offset: Int!) {
        pokemon_v2_pokemon(limit: $limit, offset: $offset, order_by: {id: asc}) {
          ${buildPokemonSummarySelection()}
        }
      }
    `,
    variables: { limit, offset },
  });

  if (!data?.data?.pokemon_v2_pokemon) {
    throwInvalidGraphQLResponse('pokemon-summary-slice');
  }

  const results = data.data.pokemon_v2_pokemon;
  await setCachedData(cacheKey, results);
  return results;
};

const buildPokemonDetailedSelection = () => `
  id
  name
  height
  weight
  pokemon_v2_pokemonstats(order_by: {pokemon_v2_stat: {id: asc}}) {
    base_stat
    pokemon_v2_stat {
      name
    }
  }
  pokemon_v2_pokemonspecy {
    is_legendary
    is_mythical
    generation_id
    pokemon_v2_pokemoncolor {
      name
    }
    pokemon_v2_pokemonshape {
      name
    }
    pokemon_v2_pokemonegggroups {
      pokemon_v2_egggroup {
        name
      }
    }
    pokemon_v2_pokemonspeciesnames(where: {pokemon_v2_language: {name: {_in: ["en", "fr", "es", "de", "it", "ja", "ko", "zh-Hans"]}}}) {
      name
      pokemon_v2_language {
        name
      }
    }
  }
  pokemon_v2_pokemontypes {
    pokemon_v2_type {
      name
    }
  }
`;

const buildPokemonSearchSelection = () => `
  id
  name
  pokemon_v2_pokemonspecy {
    pokemon_v2_pokemonspeciesnames(where: {pokemon_v2_language: {name: {_in: ["en", "fr", "es", "de", "it", "ja", "ko", "zh-Hans"]}}}) {
      name
      pokemon_v2_language {
        name
      }
    }
  }
`;

const fetchPokemonBatches = async <T>(
  cacheBase: string,
  buildQuery: (offset: number, limit: number) => { query: string; variables: Record<string, unknown> },
  batchSize: number,
): Promise<T[][]> => {
  const launchAt = (index: number, signal: AbortSignal): Promise<T[]> => {
    const offset = index * batchSize;
    const { query, variables } = buildQuery(offset, batchSize);
    const request = fetchBatch<T>(query, getBatchCacheKey(cacheBase, index), variables, signal);
    // The tail request can be cancelled once the previous page proves that it
    // is the final page. Attach a handler immediately so a fast rejection
    // cannot become an unhandled promise before the loop reaches the tail.
    void request.catch(() => undefined);
    return request;
  };

  // One-batch lookahead: while batch N is in flight, N+1 is already
  // downloading, so a full catalog load pays roughly half the serial latency.
  // The tail request is aborted as soon as N proves that there is no N+1.
  const batches: T[][] = [];
  let cursor = 0;
  let current = launchAt(cursor++, new AbortController().signal);
  let followingController = new AbortController();
  let following = launchAt(cursor++, followingController.signal);

  try {
    for (;;) {
      const batch = await current;
      batches.push(batch);

      if (batch.length < batchSize) break;

      current = following;
      followingController = new AbortController();
      following = launchAt(cursor++, followingController.signal);
    }
  } finally {
    followingController.abort();
    await following.catch(() => undefined);
  }

  return batches;
};

const fetchMoveBatches = async <T>(
  cacheBase: string,
  buildQuery: (offset: number, limit: number) => { query: string; variables: Record<string, unknown> },
  batchSize: number,
  maxResults?: number,
): Promise<T[][]> => {
  const batches: T[][] = [];
  let offset = 0;

  while (true) {
    const requestLimit = maxResults === undefined
      ? batchSize
      : Math.min(batchSize, Math.max(maxResults - offset, 0));
    if (requestLimit === 0) break;

    const cacheKey = getBatchCacheKey(cacheBase, Math.floor(offset / batchSize));
    const cached = await getCachedData<T[]>(cacheKey);
    if (cached) {
      batches.push(cached);
      if (cached.length < requestLimit) {
        break;
      }
      offset += requestLimit;
      continue;
    }

    const { query, variables } = buildQuery(offset, requestLimit);
    const { data } = await graphqlClient.post<{ data?: { pokemon_v2_move?: T[] } }>('/graphql/v1beta', { query, variables });

    if (!data?.data?.pokemon_v2_move) {
      throwInvalidGraphQLResponse('move-batches');
    }

    const results = data.data.pokemon_v2_move;
    batches.push(results);
    await setCachedData(cacheKey, results);

    if (results.length < requestLimit) {
      break;
    }

    offset += requestLimit;
  }

  return batches;
};

export const getAllPokemonSummary = async (): Promise<GraphQLPokemonSummary[]> => {
  const cacheKey = 'all-pokemon-summary-v1';
  
  const cached = await getCachedData<GraphQLPokemonSummary[]>(cacheKey);
  if (cached) return cached;

  try {
    const batches = await fetchPokemonBatches<GraphQLPokemonSummary>(
      'all-pokemon-summary-paginated-v1',
      (offset, limit) => ({
        query: `
          query GetAllPokemonSummary($limit: Int!, $offset: Int!) {
            pokemon_v2_pokemon(limit: $limit, offset: $offset, order_by: {id: asc}) {
              ${buildPokemonSummarySelection()}
            }
          }
        `,
        variables: { limit, offset },
      }),
      BATCH_SIZE,
    );
    const results = batches.flat();
    await setCachedData(cacheKey, results);
    return results;
  } catch (error) {
    const cachedFallback = await getCachedData<GraphQLPokemonSummary[]>(cacheKey, true);
    if (cachedFallback) return cachedFallback;
    throw error;
  }
};

export const getAllPokemonSummaryPaginated = async (): Promise<GraphQLPokemonSummary[][]> => {
  return fetchPokemonBatches<GraphQLPokemonSummary>(
    'all-pokemon-summary-paginated-v1',
    (offset, limit) => ({
      query: `
        query GetAllPokemonSummaryPaginated($limit: Int!, $offset: Int!) {
          pokemon_v2_pokemon(limit: $limit, offset: $offset, order_by: {id: asc}) {
            ${buildPokemonSummarySelection()}
          }
        }
      `,
      variables: { limit, offset },
    }),
    BATCH_SIZE,
  );
};

export const getAllPokemonSearchIndex = async (): Promise<GraphQLPokemonSearchIndex[]> => {
  const cacheKey = 'all-pokemon-search-index-v1';

  const cached = await getCachedData<GraphQLPokemonSearchIndex[]>(cacheKey);
  if (cached) return cached;

  try {
    const batches = await fetchPokemonBatches<GraphQLPokemonSearchIndex>(
      'all-pokemon-search-index-paginated-v1',
      (offset, limit) => ({
        query: `
          query GetAllPokemonSearchIndex($limit: Int!, $offset: Int!) {
            pokemon_v2_pokemon(limit: $limit, offset: $offset, order_by: {id: asc}) {
              ${buildPokemonSearchSelection()}
            }
          }
        `,
        variables: { limit, offset },
      }),
      SEARCH_BATCH_SIZE,
    );
    const results = batches.flat();
    await setCachedData(cacheKey, results);
    return results;
  } catch (error) {
    const cachedFallback = await getCachedData<GraphQLPokemonSearchIndex[]>(cacheKey, true);
    if (cachedFallback) return cachedFallback;
    throw error;
  }
};

export const getPokemonDetailedByType = async (type: string): Promise<PokemonBasicData[]> => {
  const cacheKey = `pokemon-detailed-by-type-v1-${type}`;
  const cached = await getCachedData<PokemonBasicData[]>(cacheKey);
  if (cached) return cached;

  const { data } = await graphqlClient.post<{ data?: { pokemon_v2_pokemon?: PokemonBasicData[] } }>('/graphql/v1beta', {
    query: `
      query GetPokemonDetailedByType($type: String!) {
        pokemon_v2_pokemon(
          where: {pokemon_v2_pokemontypes: {pokemon_v2_type: {name: {_eq: $type}}}}
          order_by: {id: asc}
        ) {
          ${buildPokemonDetailedSelection()}
        }
      }
    `,
    variables: { type },
  });

  if (!data?.data?.pokemon_v2_pokemon) {
    throwInvalidGraphQLResponse('pokemon-detailed-by-type');
  }

  const results = data.data.pokemon_v2_pokemon;
  await setCachedData(cacheKey, results);
  return results;
};

export const getAllPokemonDetailed = async (): Promise<PokemonBasicData[]> => {
  const cacheKey = 'all-pokemon-detailed-v9';
  
  const cached = await getCachedData<PokemonBasicData[]>(cacheKey);
  if (cached && cached.length > 0 && cached[0]?.pokemon_v2_pokemonspecy) {
    return cached;
  }

  try {
    const paginatedResults = await getAllPokemonDetailedPaginated();
    const flattenedResults = paginatedResults.flat();
    if (flattenedResults.length > 0) {
      await setCachedData(cacheKey, flattenedResults);
      return flattenedResults;
    }
    throwInvalidGraphQLResponse('pokemon-detailed');
  } catch (error) {
    console.error('Failed to fetch detailed Pokémon data:', error instanceof Error ? error.name : 'UnknownError');
    const cachedFallback = await getCachedData<PokemonBasicData[]>(cacheKey, true);
    if (cachedFallback && cachedFallback.length > 0) {
      return cachedFallback;
    }
    throw error;
  }
};

export const getAllPokemonDetailedPaginated = async (): Promise<PokemonBasicData[][]> => {
  return fetchPokemonBatches<PokemonBasicData>(
    'all-pokemon-detailed-paginated-v2',
    (offset, limit) => ({
      query: `
        query GetAllPokemonDetailedPaginated($limit: Int!, $offset: Int!) {
          pokemon_v2_pokemon(limit: $limit, offset: $offset, order_by: {id: asc}) {
            ${buildPokemonDetailedSelection()}
          }
        }
      `,
      variables: { limit, offset },
    }),
    BATCH_SIZE,
  );
};

export const getLocalizedPokemonData = async (name: string, languageId: number): Promise<LocalizedPokemonData> => {
  const cacheKey = `localized-pokemon-${name}-${languageId}`;
  try {
    const query = `
      query GetLocalizedPokemon($name: String!, $languageId: Int!) {
        pokemon_v2_pokemonspecies(where: {name: {_eq: $name}}) {
          pokemon_v2_pokemonspeciesnames(where: {language_id: {_eq: $languageId}}) {
            name
            pokemon_v2_language {
              name
            }
          }
          pokemon_v2_pokemonspeciesflavortexts(where: {language_id: {_eq: $languageId}}, limit: 5) {
            flavor_text
            pokemon_v2_language {
              name
            }
          }
        }
      }
    `;

    const { data } = await graphqlClient.post<{ data?: { pokemon_v2_pokemonspecies?: LocalizedPokemonData[] } }>('/graphql/v1beta', { 
      query, 
      variables: { name, languageId } 
    });
    
    if (!data?.data?.pokemon_v2_pokemonspecies?.[0]) {
      throwInvalidGraphQLResponse('localized-pokemon');
    }
    
    const results = data.data.pokemon_v2_pokemonspecies[0];
    await setCachedData(cacheKey, results);
    return results;
  } catch (error) {
    const cached = await getCachedData<LocalizedPokemonData>(cacheKey, true);
    if (cached) return cached;
    throw error;
  }
};

export const getPokemonMovesLocalized = async (name: string, languageId: number): Promise<GraphQLPokemonMoveData[]> => {
  const cacheKey = `localized-moves-${name}-${languageId}`;
  try {
    const query = `
      query GetPokemonMoves($name: String!, $languageId: Int!) {
        pokemon_v2_pokemon(where: {name: {_eq: $name}}) {
          pokemon_v2_pokemonmoves(distinct_on: move_id, order_by: {move_id: asc}) {
            pokemon_v2_move {
              name
              power
              accuracy
              pokemon_v2_type {
                name
              }
              pokemon_v2_movedamageclass {
                name
              }
              pokemon_v2_movenames(where: {language_id: {_eq: $languageId}}) {
                name
              }
              pokemon_v2_moveflavortexts(where: {language_id: {_eq: $languageId}}, limit: 1) {
                flavor_text
              }
            }
          }
        }
      }
    `;

    const { data } = await graphqlClient.post<{ data: { pokemon_v2_pokemon: Array<{ pokemon_v2_pokemonmoves: GraphQLPokemonMoveData[] }> } }>('/graphql/v1beta', { 
      query, 
      variables: { name, languageId } 
    });
    
    const pokemon = data?.data?.pokemon_v2_pokemon;
    if (!pokemon) {
      throwInvalidGraphQLResponse('localized-pokemon-moves');
    }

    const result = pokemon[0]?.pokemon_v2_pokemonmoves ?? [];
    await setCachedData(cacheKey, result);
    return result;
  } catch (error) {
    const cached = await getCachedData<GraphQLPokemonMoveData[]>(cacheKey, true);
    if (cached) return cached;
    throw error;
  }
};

export const getAllMoves = async (languageId: number, maxResults?: number): Promise<GraphQLMoveData[]> => {
  const resultLimit = maxResults === undefined
    ? undefined
    : Math.max(1, Math.min(Math.floor(maxResults), 1000));
  const cacheKey = `all-moves-v3-${languageId}-${resultLimit ?? 'all'}`;
  const cached = await getCachedData<GraphQLMoveData[]>(cacheKey);
  if (cached) return cached;

  try {
    const batches = await fetchMoveBatches<GraphQLMoveData>(
      `all-moves-paginated-v3-${languageId}-${resultLimit ?? 'all'}`,
      (offset, limit) => ({
        query: `
          query GetAllMoves($limit: Int!, $offset: Int!, $languageId: Int!) {
            pokemon_v2_move(limit: $limit, offset: $offset, order_by: {id: asc}) {
              id
              name
              power
              accuracy
              pp
              priority
              generation_id
              pokemon_v2_type {
                name
              }
              pokemon_v2_movedamageclass {
                name
              }
              pokemon_v2_movenames(where: {language_id: {_eq: $languageId}}) {
                name
              }
              pokemon_v2_moveflavortexts(where: {language_id: {_eq: $languageId}}, limit: 1) {
                flavor_text
              }
              pokemon_v2_moveeffect {
                pokemon_v2_moveeffecteffecttexts(where: {language_id: {_eq: $languageId}}) {
                  short_effect
                  effect
                }
              }
            }
          }
        `,
        variables: { limit, offset, languageId },
      }),
      MOVE_BATCH_SIZE,
      resultLimit,
    );

    const results = batches.flat();
    await setCachedData(cacheKey, results);
    return results;
  } catch (error) {
    console.error('Failed to fetch all moves:', error instanceof Error ? error.name : 'UnknownError');
    const cached = await getCachedData<GraphQLMoveData[]>(cacheKey, true);
    if (cached) return cached;
    throw error;
  }
};

export const getMovePokemonLearners = async (moveName: string, languageId: number): Promise<GraphQLMovePokemonData[]> => {
  const cacheKey = `move-learners-v2-${moveName}-${languageId}`;
  const cached = await getCachedData<GraphQLMovePokemonData[]>(cacheKey);
  if (cached) return cached;

  try {
    const query = `
      query GetMoveLearners($moveName: String!, $languageId: Int!) {
        pokemon_v2_pokemonmove(
          where: {pokemon_v2_move: {name: {_eq: $moveName}}}
          order_by: {pokemon_id: asc}
        ) {
          level
          pokemon_v2_movelearnmethod {
            name
          }
          pokemon_v2_pokemon {
            id
            name
            pokemon_v2_pokemontypes {
              pokemon_v2_type {
                name
              }
            }
            pokemon_v2_pokemonspecy {
              pokemon_v2_pokemonspeciesnames(where: {language_id: {_eq: $languageId}}) {
                name
              }
            }
          }
        }
      }
    `;

    const { data } = await graphqlClient.post<{ data?: { pokemon_v2_pokemonmove?: GraphQLMovePokemonData[] } }>('/graphql/v1beta', {
      query,
      variables: { moveName, languageId },
    });

    if (!data?.data?.pokemon_v2_pokemonmove) {
      throwInvalidGraphQLResponse('move-pokemon-learners');
    }

    const results = data.data.pokemon_v2_pokemonmove;
    await setCachedData(cacheKey, results);
    return results;
  } catch (error) {
    const cached = await getCachedData<GraphQLMovePokemonData[]>(cacheKey, true);
    if (cached) return cached;
    throw error;
  }
};

export const getAllAbilities = async (languageId: number, maxResults = 1000): Promise<GraphQLAbilityData[]> => {
  const resultLimit = Math.max(1, Math.min(Math.floor(maxResults), 1000));
  const cacheKey = `all-abilities-v3-${languageId}-${resultLimit}`;
  const cached = await getCachedData<GraphQLAbilityData[]>(cacheKey);
  if (cached) return cached;

  try {
    const query = `
      query GetAllAbilities($languageId: Int!, $limit: Int!) {
        pokemon_v2_ability(limit: $limit, order_by: {id: asc}, where: {is_main_series: {_eq: true}}) {
          id
          name
          generation_id
          is_main_series
          pokemon_v2_abilitynames(where: {language_id: {_eq: $languageId}}) {
            name
          }
          pokemon_v2_abilityeffecttexts(where: {language_id: {_eq: $languageId}}) {
            short_effect
            effect
          }
          pokemon_v2_abilityflavortexts(
            where: {language_id: {_eq: $languageId}}
            order_by: {version_group_id: desc}
            limit: 1
          ) {
            flavor_text
            pokemon_v2_versiongroup {
              name
            }
          }
        }
      }
    `;

    const { data } = await graphqlClient.post<{ data?: { pokemon_v2_ability?: GraphQLAbilityData[] } }>('/graphql/v1beta', {
      query,
      variables: { languageId, limit: resultLimit },
    });

    if (!data?.data?.pokemon_v2_ability) {
      throwInvalidGraphQLResponse('abilities');
    }

    const results = data.data.pokemon_v2_ability;
    await setCachedData(cacheKey, results);
    return results;
  } catch (error) {
    const cached = await getCachedData<GraphQLAbilityData[]>(cacheKey, true);
    if (cached) return cached;
    throw error;
  }
};

export const getAbilityPokemon = async (abilityName: string, languageId: number): Promise<GraphQLAbilityPokemonData[]> => {
  const cacheKey = `ability-pokemon-v1-${abilityName}-${languageId}`;
  const cached = await getCachedData<GraphQLAbilityPokemonData[]>(cacheKey);
  if (cached) return cached;

  try {
    const query = `
      query GetAbilityPokemon($abilityName: String!, $languageId: Int!) {
        pokemon_v2_pokemonability(
          where: {pokemon_v2_ability: {name: {_eq: $abilityName}}}
          order_by: {pokemon_id: asc}
        ) {
          is_hidden
          slot
          pokemon_v2_pokemon {
            id
            name
            pokemon_v2_pokemontypes {
              pokemon_v2_type {
                name
              }
            }
            pokemon_v2_pokemonspecy {
              pokemon_v2_pokemonspeciesnames(where: {language_id: {_eq: $languageId}}) {
                name
              }
            }
          }
        }
      }
    `;

    const { data } = await graphqlClient.post<{ data?: { pokemon_v2_pokemonability?: GraphQLAbilityPokemonData[] } }>('/graphql/v1beta', {
      query,
      variables: { abilityName, languageId },
    });

    if (!data?.data?.pokemon_v2_pokemonability) {
      throwInvalidGraphQLResponse('ability-pokemon');
    }

    const results = data.data.pokemon_v2_pokemonability;
    await setCachedData(cacheKey, results);
    return results;
  } catch (error) {
    const cached = await getCachedData<GraphQLAbilityPokemonData[]>(cacheKey, true);
    if (cached) return cached;
    throw error;
  }
};

// Categories excluded from the browse grid: spin-off/debug/crafting items with
// auto-generated or obscure names (e.g. "dynamax-crystal-and458") that have no
// artwork in the sprites repo and aren't relevant to a core-series Pokédex.
const EXCLUDED_ITEM_CATEGORIES = [
  'unused',
  'plot-advancement',
  'data-cards',
  'miracle-shooter',
  'dynamax-crystals',
  'tm-materials',
  'picnic',
  'sandwich-ingredients',
  'curry-ingredients',
  'all-machines',
];

export const getAllItems = async (languageId: number, maxResults = 2000): Promise<GraphQLItemData[]> => {
  const resultLimit = Math.max(1, Math.min(Math.floor(maxResults), 2000));
  const cacheKey = `all-items-v3-${languageId}-${resultLimit}`;
  const cached = await getCachedData<GraphQLItemData[]>(cacheKey);
  if (cached) return cached;

  try {
    const query = `
      query GetAllItems($languageId: Int!, $limit: Int!, $excludedCategories: [String!]) {
        pokemon_v2_item(
          limit: $limit
          order_by: {id: asc}
          where: {
            pokemon_v2_itemcategory: {id: {_is_null: false}, name: {_nin: $excludedCategories}}
            pokemon_v2_itemnames: {language_id: {_eq: $languageId}}
          }
        ) {
          id
          name
          cost
          pokemon_v2_itemcategory {
            name
          }
          pokemon_v2_itemnames(where: {language_id: {_eq: $languageId}}) {
            name
          }
          pokemon_v2_itemeffecttexts(where: {language_id: {_eq: $languageId}}) {
            effect
            short_effect
          }
          pokemon_v2_itemflavortexts(where: {language_id: {_eq: $languageId}}, limit: 1) {
            flavor_text
          }
        }
      }
    `;

    const { data } = await graphqlClient.post<{ data?: { pokemon_v2_item?: GraphQLItemData[] } }>('/graphql/v1beta', {
      query,
      variables: { languageId, limit: resultLimit, excludedCategories: EXCLUDED_ITEM_CATEGORIES },
    });

    if (!data?.data?.pokemon_v2_item) {
      throwInvalidGraphQLResponse('items');
    }

    const results = data.data.pokemon_v2_item;
    await setCachedData(cacheKey, results);
    return results;
  } catch (error) {
    const cached = await getCachedData<GraphQLItemData[]>(cacheKey, true);
    if (cached) return cached;
    throw error;
  }
};

export const getItemDetail = async (name: string, languageId: number): Promise<GraphQLItemData | null> => {
  const cacheKey = `item-detail-v1-${name}-${languageId}`;
  const cached = await getCachedData<GraphQLItemData>(cacheKey);
  if (cached) return cached;

  try {
    const query = `
      query GetItemDetail($name: String!, $languageId: Int!) {
        pokemon_v2_item(where: {name: {_eq: $name}}) {
          id
          name
          cost
          pokemon_v2_itemcategory {
            name
          }
          pokemon_v2_itemnames(where: {language_id: {_eq: $languageId}}) {
            name
          }
          pokemon_v2_itemeffecttexts(where: {language_id: {_eq: $languageId}}) {
            effect
            short_effect
          }
          pokemon_v2_itemflavortexts(where: {language_id: {_eq: $languageId}}, limit: 1) {
            flavor_text
          }
        }
      }
    `;

    const { data } = await graphqlClient.post<{ data?: { pokemon_v2_item?: GraphQLItemData[] } }>('/graphql/v1beta', {
      query,
      variables: { name, languageId },
    });

    const result = data?.data?.pokemon_v2_item?.[0];
    if (!result) return null;

    await setCachedData(cacheKey, result);
    return result;
  } catch (error) {
    const cached = await getCachedData<GraphQLItemData>(cacheKey, true);
    if (cached) return cached;
    throw error;
  }
};
