export function normalizeSearchText(value: string): string {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase()
    .trim();
}

/** A debounced search may update global state only while it still represents user input. */
export function shouldCommitPokemonSearch(
  localSearch: string,
  pendingUserSearch: string | null,
): boolean {
  return pendingUserSearch !== null && pendingUserSearch === localSearch;
}

export function getPokemonSearchFromUrl(search: string): string {
  return new URLSearchParams(search).get('q') ?? '';
}

/**
 * Treat padded IDs and IDs prefixed with `#` as exact lookups while keeping
 * unpadded numeric input useful for partial ID searches.
 */
export function getExactNumericPokemonId(searchTerm: string): number | null {
  const trimmed = searchTerm.trim();
  const withoutHash = trimmed.startsWith('#') ? trimmed.slice(1).trim() : trimmed;
  const isPadded = /^0\d/.test(withoutHash);

  if (!/^\d+$/.test(withoutHash) || (!trimmed.startsWith('#') && !isPadded)) {
    return null;
  }

  const id = Number(withoutHash);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

type Measurement = number | null | undefined;

/** The top of the height slider represents an open-ended 25 m+ bound. */
export function isHeightWithinRange(height: number, min: number, max: number): boolean {
  if (!Number.isFinite(height)) return false;
  return height >= min && (max >= 25 || height <= max);
}

export function shouldUseCompletePokemonSummary({
  hasOtherFilters,
  showCaughtOnly,
  showFavoritesOnly,
}: {
  hasOtherFilters: boolean;
  showCaughtOnly: 'all' | 'caught' | 'uncaught';
  showFavoritesOnly: boolean;
}): boolean {
  return hasOtherFilters || showCaughtOnly !== 'all' || showFavoritesOnly;
}

export function shouldShowInitialPokemonListError(
  isBasicMode: boolean,
  hasListData: boolean,
  error: unknown,
): boolean {
  return isBasicMode && !hasListData && error !== null && error !== undefined;
}

/** Keep missing/non-positive PokéAPI measurements after known values. */
export function comparePokemonMeasurements(
  left: Measurement,
  right: Measurement,
  direction: 'asc' | 'desc',
): number {
  const leftValue = typeof left === 'number' && Number.isFinite(left) && left > 0 ? left : null;
  const rightValue = typeof right === 'number' && Number.isFinite(right) && right > 0 ? right : null;

  if (leftValue === null && rightValue === null) return 0;
  if (leftValue === null) return 1;
  if (rightValue === null) return -1;

  return direction === 'asc' ? leftValue - rightValue : rightValue - leftValue;
}
